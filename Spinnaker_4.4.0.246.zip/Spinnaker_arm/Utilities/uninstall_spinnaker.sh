#!/bin/sh
#
# Helper script to uninstall Spinnaker from OSX machines. Can be run
# from anywhere on the machine. After checking to see if Spinnaker
# is installed on the machine, remove all files installed as a
# part of the Spinnaker package then delete the corresponding
# entry from package utils.
#

# Elevate permissions if necessary
if [ "$EUID" != 0 ]
then
    echo "Uninstallation of Spinnaker requires elevated permissions, eg."
    echo "sudo sh uninstall_spinnaker.sh"
    exit 1
fi

MY_YESNO_PROMPT='[Y/n] $ '

echo "This is a script to assist with the removal of the Spinnaker SDK."
echo "Would you like to continue and remove all installed Spinnaker packages, including modified files?"
printf "$MY_YESNO_PROMPT"
read confirm
if ! ( [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ] )
then
    exit 0
fi

# Run pre-uninstall analytics and backup
echo "Running pre-uninstall tasks..."
if [ -f "/Applications/Spinnaker/Utilities/preuninstall" ]; then
    sh /Applications/Spinnaker/Utilities/preuninstall "Spinnaker-${VERSION_STRING:-Unknown}.pkg"
elif [ -f "./preuninstall" ]; then
    sh ./preuninstall "Spinnaker-${VERSION_STRING:-Unknown}.pkg"
fi

# Remove zprofile.spinnakergentl from zprofile using the configure script, suppress any expected output.
echo "Removing Spinnaker GenTL producer path from zprofile if configured..."
sh /Applications/Spinnaker/Utilities/configure_gentl_path.sh -u > /dev/null

SPINNAKER_INSTALL_APPS_DIR=/Applications/Spinnaker/apps
SPINNAKER_LIBRARY_DIR=/Applications/Spinnaker/lib
SYSTEM_LIBRARY_DIR=/usr/local/lib
SYSTEM_DOCUMENTATION_DIR=/usr/local/share/doc/
MAJOR_VERSION=4

SYMLINKS=("libSpinnaker" \
          "libSpinnaker_C" \
          "libSpinUpdate" \
          "libSpinVideo" \
          "libSpinVideo_C")

SPINNAKER_PKGS=$(pkgutil --pkgs | grep com.spinnaker | sort)
if [ -z "$SPINNAKER_PKGS" ]
then
    echo "No installation of Spinnaker detected on system."
fi

if [ -d "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker Examples.app" ]
then
    echo "Removing Spinnaker Examples shortcut..."
    rm -rf "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker Examples.app"
fi

# Documentation apps are placed in Spinnaker/apps, also need to remove those
if [ -d "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker C++ API Reference.app" ]
then
    echo "Removing C++ API Reference Manual..."
    rm -rf "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker C++ API Reference.app"
fi

if [ -d "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker Github Shortcut.app" ]
then
    echo "Removing Spinnaker Github Shortcut..."
    rm -rf "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker Github Shortcut.app"
fi

if [ -d "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker C API Reference.app" ]
then
    echo "Removing C API Reference Manual..."
    rm -rf "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker C API Reference.app"
fi

if [ -d "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker Utilities.app" ]
then
    echo "Removing Spinnaker Utilities shortcut..."
    rm -rf "$SPINNAKER_INSTALL_APPS_DIR/Spinnaker Utilities.app"
fi

# Remove old links if they exist
echo "Removing symlinks..."
for link in ${SYMLINKS[@]}
do
  # Executes if link is a normal file or a (potentially broken) symlink
  if [[ (-e $SYSTEM_LIBRARY_DIR/$link.dylib) || (-L $SYSTEM_LIBRARY_DIR/$link.dylib) ]]
  then
    unlink $SYSTEM_LIBRARY_DIR/$link.dylib
    unlink $SYSTEM_LIBRARY_DIR/$link.$MAJOR_VERSION.dylib
  fi

  if [[ (-e $SPINNAKER_LIBRARY_DIR/$link.dylib) || (-L $SPINNAKER_LIBRARY_DIR/$link.dylib) ]]
  then
    unlink $SPINNAKER_LIBRARY_DIR/$link.dylib
    unlink $SPINNAKER_LIBRARY_DIR/$link.$MAJOR_VERSION.dylib
  fi
done

# Check pkgutils to see if Spinnaker examples are installed
for pkg in ${SPINNAKER_PKGS[@]}
do
    pkgname=$(pkgutil --pkgs | grep "${pkg}$")
    if [ -z "$pkgname" ]
    then
        echo "${pkg} is not installed. Checking next package..."
    fi
    # Remove all files installed by each package
    echo "Removing all files installed by Spinnaker package: $pkgname"
    cd /
    pkgutil --only-files --files $pkgname | tr '\n' '\0' | xargs -n 1 -0 rm -f

    ALL_DIRS=$(pkgutil --only-dirs --files $pkgname | tail -r)
    for dir in ${ALL_DIRS}
    do
        # Remove all emptied directories installed by package
        if [ -d ${dir} ] && [ -z "$(ls -A ${dir})" ]
        then
            rmdir ${dir}
        fi
    done
    pkgutil --forget $pkgname
done

if [ -L $SYSTEM_DOCUMENTATION_DIR/spinnaker-doc ]
then
    echo "Removing link to Spinnaker Documentation..."
    unlink $SYSTEM_DOCUMENTATION_DIR/spinnaker-doc
fi

# Clean up persistence data
SPINNAKERDATA="${HOME}/.config/spinnaker"
IniFiles="${SPINNAKERDATA}/GenTLSysReg.ini
${SPINNAKERDATA}/GenTLIfReg.ini
${SPINNAKERDATA}/GenTLIfGevReg.ini
${SPINNAKERDATA}/GenTLUsbReg.ini
${SPINNAKERDATA}/GenTLGevReg.ini
${SPINNAKERDATA}/SpinView_Qt.ini"

for file in $IniFiles
do
    # Check if file exist
    if [ -e "$file" ]; then
        rm $file
    fi
done

echo "Done uninstalling Spinnaker!"
