//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

/**
 *  @example NodeMapCallback_C.c
 *
 *  @brief NodeMapCallback_C.c shows how to use nodemap callbacks. It
 *  relies on information provided in the Enumeration_C, Acquisition_C, and
 *  NodeMapInfo_C examples. As callbacks are very similar to events, it may be
 *  a good idea to explore this example prior to tackling the events examples.
 *
 *  This example focuses on creating, registering, using, and unregistering
 *  callbacks. A callback requires a certain function signature, which allows
 *  it to be registered to and access a node. Events, while slightly more
 *  complex, follow this same pattern.
 *
 *  Once comfortable with NodeMapCallback_C, we suggest checking out any of the
 *  events examples: EnumerationEvents_C, ImageEvents_C, or Logging_C.
 *
 *  Please leave us feedback at: https://www.surveymonkey.com/r/TDYMVAPI
 *  More source code examples at: https://github.com/Teledyne-MV/Spinnaker-Examples
 *  Need help? Check out our forum at: https://teledynevisionsolutions.zendesk.com/hc/en-us/community/topics
 */

#include "SpinnakerC.h"
#include "SpinnakerDefsC.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"

// This macro helps with C-strings.
#define MAX_BUFF_LEN 256

// Create dynamic array to hold callback handles
typedef struct
{
    spinNodeCallbackHandle* callback;
    spinNodeHandle* node;
    size_t size;
    size_t capacity;
} callbackArray;

// Initialize the array
void initArray(callbackArray* arr, size_t initialCapacity)
{
    arr->callback = (spinNodeCallbackHandle*)malloc(initialCapacity * sizeof(spinNodeCallbackHandle));
    arr->node = (spinNodeHandle*)malloc(initialCapacity * sizeof(spinNodeHandle));
    arr->size = 0;
    arr->capacity = initialCapacity;
}

// Push an element to the end
void push(callbackArray* arr, spinNodeCallbackHandle callbackHandle, spinNodeHandle nodeHandle)
{
    if (arr->size == arr->capacity)
    {
        arr->capacity *= 2;
        arr->callback = (spinNodeCallbackHandle*)realloc(arr->callback, arr->capacity * sizeof(spinNodeCallbackHandle));
        arr->node = (spinNodeHandle*)realloc(arr->node, arr->capacity * sizeof(spinNodeHandle));
    }

    arr->callback[arr->size] = callbackHandle;
    arr->node[arr->size] = nodeHandle;
    arr->size++;
}

// Pop an element from the end
void pop(callbackArray* arr, spinNodeCallbackHandle* callbackHandle, spinNodeHandle* nodeHandle)
{
    if (arr->size == 0)
    {
        printf("Error: Attempt to pop from an empty array..\n\n");
    }

    arr->size--;
    *callbackHandle = arr->callback[arr->size];
    *nodeHandle = arr->node[arr->size];
}

// Get the current size of the array
size_t getSize(callbackArray* arr)
{
    return arr->size;
}

// Free the array memory
void freeArray(callbackArray* arr)
{
    free(arr->callback);
    free(arr->node);
    arr->callback = NULL;
    arr->node = NULL;
    arr->size = 0;
    arr->capacity = 0;
}

char lastErrorMessage[MAX_BUFF_LEN];
size_t lenLastErrorMessage = MAX_BUFF_LEN;

// Helper for getting error messages
char* GetLastErrorMessage()
{
    // Note: lastErrorMessage is shared across multiple threads; a different thread could overwrite the last error
    // message before this function is called to grab the latest message
    spinErrorGetLastMessage(lastErrorMessage, &lenLastErrorMessage);
    return lastErrorMessage;
}

// This function helps to check if a node is readable
bool8_t IsReadable(spinNodeHandle hNode, char nodeName[])
{
    spinError err = SPINNAKER_ERR_SUCCESS;
    bool8_t pbReadable = False;
    err = spinNodeIsReadable(hNode, &pbReadable);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return False;
    }
    return pbReadable;
}

// This function helps to check if a node is writable
bool8_t IsWritable(spinNodeHandle hNode, char nodeName[])
{
    spinError err = SPINNAKER_ERR_SUCCESS;
    bool8_t pbWritable = False;
    err = spinNodeIsWritable(hNode, &pbWritable);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return False;
    }
    return pbWritable;
}

// This function handles the error prints when a node or entry is
// not readable/writable on the connected camera
void PrintRetrieveNodeFailure(char node[], char name[])
{
    printf("Unable to get %s (%s %s retrieval failed).\n\n", node, name, node);
}

// This is the first of three callback functions. Notice the function signature.
// This callback function will be registered to the height node.
void onHeightNodeUpdate(spinNodeHandle hNode)
{
    spinError err = SPINNAKER_ERR_SUCCESS;
    int64_t height = 0;

    if (IsReadable(hNode, "Height"))
    {
        err = spinIntegerGetValue(hNode, &height);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve height. Non-fatal error %d...\n\n", err);
            return;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "Height");
        return;
    }
    printf("Height callback message:\n");
    printf("\tLook! Height changed to %d...\n\n", (int)height);
}

// This is the second of three callback functions. Notice that despite different
// names, everything else is exactly the same as the first. This callback
// function will be registered to the gain node.
void onGainNodeUpdate(spinNodeHandle hNode)
{
    spinError err = SPINNAKER_ERR_SUCCESS;
    double gain = 0.0;

    if (IsReadable(hNode, "Gain"))
    {
        err = spinFloatGetValue(hNode, &gain);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve gain. Non-fatal error %d...\n\n", err);
            return;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "Gain");
        return;
    }

    printf("Gain callback message:\n");
    printf("\tLook now! Gain changed to %f...\n\n", gain);
}

// This is the third of three callback functions. Notice the function signature.
// This callback function will be registered to the event feature nodes.
void onEventNodeUpdate(spinNodeHandle hNode)
{
    spinError err = SPINNAKER_ERR_SUCCESS;
    spinNodeType nodeType = UnknownNode;
    char nodeName[MAX_BUFF_LEN];
    size_t lenNodeName = MAX_BUFF_LEN;

    // Retrieve node name
    err = spinNodeGetName(hNode, nodeName, &lenNodeName);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        strcpy(nodeName, "Unknown name");
    }

    if (IsReadable(hNode, nodeName))
    {
        err = spinNodeGetType(hNode, &nodeType);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve node type. Non-fatal error: %s [%d]\n\n", GetLastErrorMessage(), err);
            return;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", nodeName);
        return;
    }

    if (nodeType == IntegerNode)
    {
        int64_t featureValue = 0;

        err = spinIntegerGetValue(hNode, &featureValue);

        printf("\t%s was changed to %lld\n", nodeName, featureValue);
    }
    else if (nodeType == BooleanNode)
    {
        bool8_t featureValue = False;

        err = spinBooleanGetValue(hNode, &featureValue);

        if (featureValue)
        {
            printf("\t%s was changed to true\n", nodeName);
        }
        else
        {
            printf("\t%s was changed to false\n", nodeName);
        }
    }
    else if (nodeType == FloatNode)
    {
        double featureValue = 0.0;

        err = spinFloatGetValue(hNode, &featureValue);

        printf("\t%s was changed to %f\n", nodeName, featureValue);
    }
    else if (nodeType == StringNode)
    {
        char featureValue[MAX_BUFF_LEN];
        size_t lenFeatureValue = MAX_BUFF_LEN;

        err = spinStringGetValue(hNode, featureValue, &lenFeatureValue);

        printf("\t%s was changed to %s\n", nodeName, featureValue);
    }
    else
    {
        printf("\t%s with node type %d was updated\n", nodeName, nodeType);
    }
}

// This function prepares the example by disabling automatic gain, creating two
// callbacks, and registering them to their respective nodes.
spinError ConfigureCallbacks(spinNodeMapHandle hNodeMap, callbackArray* handleArray)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    printf("\n\n*** CONFIGURING CALLBACKS ***\n\n");

    //
    // Turn off automatic gain
    //
    // *** NOTES ***
    // Automatic gain prevents the manual configuration of gain and needs to
    // be turned off for this example.
    //
    // *** LATER ***
    // Automatic gain is turned off at the end of the example in order to
    // restore the camera to its default state.
    //
    spinNodeHandle hGainAuto = NULL;
    spinNodeHandle hGainAutoOff = NULL;
    int64_t gainAutoOff = 0;

    err = spinNodeMapGetNode(hNodeMap, "GainAuto", &hGainAuto);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to disable automatic gain (node retrieval). Aborting with error %d...\n\n", err);
        return err;
    }

    if (IsReadable(hGainAuto, "GainAuto"))
    {
        err = spinEnumerationGetEntryByName(hGainAuto, "Off", &hGainAutoOff);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to disable automatic gain (enum entry retrieval). Aborting with error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "GainAuto");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    if (IsReadable(hGainAutoOff, "GainAutoOff"))
    {
        err = spinEnumerationEntryGetIntValue(hGainAutoOff, &gainAutoOff);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf(
                "Unable to disable automatic gain (enum entry int value retrieval). Aborting with error %d...\n\n",
                err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("entry", "GainAuto 'Off'");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    if (IsWritable(hGainAuto, "GainAuto"))
    {
        err = spinEnumerationSetIntValue(hGainAuto, gainAutoOff);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to disable automatic gain (enum entry setting). Aborting with error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "GainAuto");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }
    printf("Automatic gain disabled...\n");

    //
    // Register callback to height node
    //
    // *** NOTES ***
    // Callbacks need to be registered to nodes, which should be writable
    // if the callback is to ever be triggered. Notice that callback
    // registration a handle - this handle is important at the end of the
    // example for deregistration.
    //
    // *** LATER ***
    // Each callback needs to be unregistered individually before releasing
    // the system or an exception will be thrown.
    //
    spinNodeHandle hHeight = NULL;

    err = spinNodeMapGetNode(hNodeMap, "Height", &hHeight);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to register height callback (node retrieval). Aborting with error %d...\n\n", err);
        return err;
    }

    spinNodeCallbackHandle callbackHeight = NULL;
    err = spinNodeRegisterCallback(hHeight, onHeightNodeUpdate, &callbackHeight);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to register height callback (callback registration). Aborting with error %d...\n\n", err);
        return err;
    }
    push(handleArray, callbackHeight, hHeight);

    printf("Height callback registered...\n");

    //
    // Register callback to gain node
    //
    // *** NOTES ***
    // Depending on the specific goal of the function, it can be important
    // to notice the node type that a callback is registered to. Notice in
    // the callback functions above that the callback registered to height
    // casts its node as an integer whereas the callback registered to gain
    // casts as a float.
    //
    // *** LATER ***
    // Each callback needs to be unregistered individually before releasing
    // the system or an exception will be thrown.
    //
    spinNodeHandle hGain = NULL;

    err = spinNodeMapGetNode(hNodeMap, "Gain", &hGain);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to register gain callback (callback registration). Aborting with error %d...\n\n", err);
        return err;
    }

    spinNodeCallbackHandle callbackGain = NULL;
    err = spinNodeRegisterCallback(hGain, onGainNodeUpdate, &callbackGain);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to register gain callback (callback registration). Aborting with error %d...\n\n", err);
        return err;
    }
    push(handleArray, callbackGain, hGain);

    printf("Gain callback registered...\n\n");

    return err;
}

spinError GetNumEvents(spinNodeMapHandle hNodeMap, size_t* numEvents)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    spinNodeHandle hEventSelector = NULL;
    size_t numEntries = 0;

    // Retrieve selector node
    err = spinNodeMapGetNode(hNodeMap, "EventSelector", &hEventSelector);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf(
            "Unable to retrieve event selector entries. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
        return err;
    }

    // Retrieve number of entries, check if readable
    if (IsReadable(hEventSelector, "EventSelector"))
    {
        err = spinEnumerationGetNumEntries(hEventSelector, &numEntries);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf(
                "Unable to retrieve number of entries. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
            return err;
        }
    }
    else
    {
        err = SPINNAKER_ERR_ACCESS_DENIED;
        printf("Unable to read number of entries. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
        return err;
    }

    *numEvents = numEntries;
    return err;
}

// This function prepares the example by disabling automatic gain, creating two
// callbacks, and registering them to their respective nodes.
spinError ConfigureEventCallbacks(spinNodeMapHandle hNodeMap, callbackArray* handleArray)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    spinNodeHandle hEventSelector = NULL;
    size_t numEntries = 0;

    printf("\n\n*** CONFIGURING EVENT CALLBACKS ***\n\n");

    // Retrieve selector node
    err = spinNodeMapGetNode(hNodeMap, "EventSelector", &hEventSelector);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve event selector entries. Skipping...\n\n");
        return SPINNAKER_ERR_SUCCESS;
    }

    // Retrieve number of entries, check if readable
    if (IsReadable(hEventSelector, "EventSelector"))
    {
        err = spinEnumerationGetNumEntries(hEventSelector, &numEntries);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve event selector entries. Skipping...\n\n");
            return SPINNAKER_ERR_SUCCESS;
        }
    }
    else
    {
        printf("Unable to retrieve event selector entries. Skipping...\n\n");
        return SPINNAKER_ERR_SUCCESS;
    }

    for (unsigned int i = 0; i < numEntries; i++)
    {
        // Retrieve entry node
        spinNodeHandle hEntry = NULL;

        err = spinEnumerationGetEntryByIndex(hEventSelector, i, &hEntry);

        // Go to next node if problem occurs
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            continue;
        }

        // Retrieve entry name
        char entryName[MAX_BUFF_LEN];
        size_t lenEntryName = MAX_BUFF_LEN;

        if (IsReadable(hEntry, "EventEntry"))
        {
            err = spinNodeGetDisplayName(hEntry, entryName, &lenEntryName);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf("\t%s: unable to retrieve event entry by display name (error %d)...\n", entryName, err);
            }
        }
        else
        {
            continue;
        }
        // Retrieve enum entry integer value
        int64_t value = 0;

        err = spinEnumerationEntryGetIntValue(hEntry, &value);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("\t%s: unable to get event entry value (error %d)...\n", entryName, err);
            continue;
        }

        // Set integer value
        if (IsWritable(hEventSelector, "EventSelector"))
        {
            err = spinEnumerationSetIntValue(hEventSelector, value);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf("\t%s: unable to set event entry value (error %d)...\n", entryName, err);
                continue;
            }
        }
        else
        {
            err = SPINNAKER_ERR_ACCESS_DENIED;
            printf("\t%s: unable to set event entry value (error %d)...\n", entryName, err);
            continue;
        }

        // Retrieve event notification node (an enumeration node)
        spinNodeHandle hEventNotification = NULL;
        err = spinNodeMapGetNode(hNodeMap, "EventNotification", &hEventNotification);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("\t%s: unable to get entry from nodemap (error %d)...\n", entryName, err);
            continue;
        }

        spinNodeHandle hEventNotificationOn = NULL;
        int64_t eventNotificationOn = 0;

        if (IsReadable(hEventNotification, "EventNotification"))
        {
            err = spinEnumerationGetEntryByName(hEventNotification, "On", &hEventNotificationOn);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf(
                    "Unable to set event notification to On (entry 'On' retrieval). Aborting with error "
                    "%d...\n\n",
                    err);
                continue;
            }
        }
        else
        {
            err = SPINNAKER_ERR_ACCESS_DENIED;
            printf(
                "Unable to read event notification mode. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
            continue;
        }

        if (IsReadable(hEventNotificationOn, "EventNotificationOn"))
        {
            err = spinEnumerationEntryGetIntValue(hEventNotificationOn, &eventNotificationOn);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf(
                    "Unable to set event notification to On (entry int value retrieval). Aborting with error "
                    "%d...\n\n",
                    err);
                continue;
            }
        }
        else
        {
            err = SPINNAKER_ERR_ACCESS_DENIED;
            printf(
                "Unable to read event notification On. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
            continue;
        }

        // Set event notification to On
        if (IsWritable(hEventNotification, "EventNotification"))
        {
            err = spinEnumerationSetIntValue(hEventNotification, eventNotificationOn);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf(
                    "Unable to set event notification to On (entry int value setting). Aborting with error "
                    "%d...\n\n",
                    err);
                continue;
            }
            printf("\t%s: enabled...\n", entryName);
        }
        else
        {
            err = SPINNAKER_ERR_ACCESS_DENIED;
            printf(
                "Unable to write to event notification. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
            continue;
        }

        // Register Event Data callbacks
        char entrySymbolic[MAX_BUFF_LEN];
        char eventDataCategoryName[MAX_BUFF_LEN];
        size_t entrySymbolicLength = MAX_BUFF_LEN;

        err = spinEnumerationEntryGetSymbolic(hEntry, entrySymbolic, &entrySymbolicLength);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            return err;
        }

        sprintf(eventDataCategoryName, "Event%sData", entrySymbolic);

        spinNodeHandle hDataCategory = NULL;
        size_t numFeatures;

        err = spinNodeMapGetNode(hNodeMap, eventDataCategoryName, &hDataCategory);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("\t%s: unable to get entry from nodemap (error %d)...\n", eventDataCategoryName, err);
            continue;
        }

        if (!IsReadable(hDataCategory, eventDataCategoryName))
        {
            printf("Unable to retrieve %s. Aborting...\n\n", eventDataCategoryName);
            continue;
        }

        err = spinCategoryGetNumFeatures(hDataCategory, &numFeatures);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve number of nodes (error %d)...\n\n", err);
            return err;
        }

        for (unsigned int j = 0; j < numFeatures; j++)
        {
            spinNodeHandle hFeatureNode = NULL;
            spinNodeType featureType = UnknownNode;
            char featureName[MAX_BUFF_LEN];
            size_t lenFeatureName = MAX_BUFF_LEN;

            // Retrieve node
            if (IsReadable(hDataCategory, eventDataCategoryName))
            {
                err = spinCategoryGetFeatureByIndex(hDataCategory, j, &hFeatureNode);
                if (err != SPINNAKER_ERR_SUCCESS)
                {
                    printf("Unable to retrieve node (error %d)...\n\n", err);
                    continue;
                }
            }
            else
            {
                err = SPINNAKER_ERR_ACCESS_DENIED;
                printf("Unable to retrieve node (error %d)...\n\n", err);
                continue;
            }

            // Retrieve node name
            err = spinNodeGetName(hFeatureNode, featureName, &lenFeatureName);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                strcpy(featureName, "Unknown name");
            }

            //
            // Register callback to event data node
            //
            // *** LATER ***
            // Each callback needs to be unregistered individually before releasing
            // the system or an exception will be thrown.
            //
            spinNodeCallbackHandle tmpNodeCallbackHandle;
            err = spinNodeRegisterCallback(hFeatureNode, onEventNodeUpdate, &tmpNodeCallbackHandle);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf(
                    "Unable to register %s callback (callback registration). Aborting with error %d...\n\n",
                    featureName,
                    err);
                continue;
            }
            push(handleArray, tmpNodeCallbackHandle, hFeatureNode);

            printf("\t\t%s callback registered...\n", featureName);
        }
    }

    return err;
}

// This function demonstrates the triggering of the nodemap callbacks. First it
// changes height, which executes the callback registered to the height node, and
// then it changes gain, which executes the callback registered to the gain node.
spinError ChangeHeightAndGain(spinNodeMapHandle hNodeMap)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    printf("\n*** CHANGING HEIGHT & GAIN ***\n\n");

    //
    // Change height to trigger height callback
    //
    // *** NOTES ***
    // Notice that changing the height only triggers the callback function
    // registered to the height node.
    //
    spinNodeHandle hHeight = NULL;
    int64_t heightToSet = 0;
    int64_t heightMax = 0;

    err = spinNodeMapGetNode(hNodeMap, "Height", &hHeight);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to change height (node retrieval). Aborting with error %d...\n\n", err);
        return err;
    }

    if (IsReadable(hHeight, "Height"))
    {
        err = spinIntegerGetMax(hHeight, &heightMax);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to change height (max retrieval). Aborting with error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "Height");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    heightToSet = heightMax;

    printf("Regular function message:\n");
    printf("\tHeight about to be set to %d...\n\n", (int)heightToSet);

    if (IsWritable(hHeight, "Height"))
    {
        err = spinIntegerSetValue(hHeight, heightToSet);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to change height (value setting). Aborting with error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "Height");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }
    //
    // Change gain to trigger gain callback
    //
    // *** NOTES ***
    // The same is true of changing the gain node; changing a node will
    // only ever trigger the callback function (or functions) currently
    // registered to it.
    //
    spinNodeHandle hGain = NULL;
    double gainToSet = 0.0;
    double gainMax = 0.0;

    err = spinNodeMapGetNode(hNodeMap, "Gain", &hGain);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to register gain callback (callback registration). Aborting with error %d...\n\n", err);
        return err;
    }

    if (IsReadable(hGain, "Gain"))
    {
        err = spinFloatGetMax(hGain, &gainMax);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to change gain (max retrieval). Aborting with error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "Gain");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    gainToSet = gainMax / 2.0;

    printf("Regular function message:\n");
    printf("\tGain about to be set to %f...\n\n", gainToSet);

    if (IsWritable(hGain, "Gain"))
    {
        err = spinFloatSetValue(hGain, gainToSet);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to change gain (value setting). Aborting with error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "Gain");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }
    return err;
}

// This function cleans up the example by deregistering the callbacks
spinError ResetCallbacks(callbackArray* handleArray)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    spinNodeCallbackHandle hCallback = NULL;
    spinNodeHandle hNode = NULL;
    char nodeName[MAX_BUFF_LEN];
    size_t lenNodeName = MAX_BUFF_LEN;

    while (handleArray->size > 0)
    {
        pop(handleArray, &hCallback, &hNode);

        //
        // Deregister node callback
        //
        // *** NOTES ***
        // It is important to deregister each callback function from each node
        // that it is registered to.
        //
        err = spinNodeDeregisterCallback(hNode, hCallback);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to deregister callback (callback deregistration). Aborting with error %d...\n\n", err);
            return err;
        }

        // Retrieve node name
        lenNodeName = MAX_BUFF_LEN;
        err = spinNodeGetName(hNode, nodeName, &lenNodeName);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            strcpy(nodeName, "Unknown name");
        }

        printf("\t\t%s callback deregistered...\n", nodeName);
    }

    return err;
}

// This function cleans up the example by resetting event notifications
spinError ResetEvents(spinNodeMapHandle hNodeMap)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    spinNodeHandle hEventSelector = NULL;
    size_t numEntries = 0;

    printf("\n\n*** RESETTING EVENT CALLBACKS ***\n\n");

    // Retrieve selector node
    err = spinNodeMapGetNode(hNodeMap, "EventSelector", &hEventSelector);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve event selector entries. Skipping...\n\n");
        return SPINNAKER_ERR_SUCCESS;
    }

    // Retrieve number of entries, check if readable
    if (IsReadable(hEventSelector, "EventSelector"))
    {
        err = spinEnumerationGetNumEntries(hEventSelector, &numEntries);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve number of entries. Skipping...\n\n");
            return SPINNAKER_ERR_SUCCESS;
        }
    }
    else
    {
        err = SPINNAKER_ERR_ACCESS_DENIED;
        printf("Unable to read number of entries. Skipping...\n\n");
        return SPINNAKER_ERR_SUCCESS;
    }

    for (unsigned int i = 0; i < numEntries; i++)
    {
        // Retrieve entry node
        spinNodeHandle hEntry = NULL;

        err = spinEnumerationGetEntryByIndex(hEventSelector, i, &hEntry);

        // Go to next node if problem occurs
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            continue;
        }

        // Retrieve entry name
        char entryName[MAX_BUFF_LEN];
        size_t lenEntryName = MAX_BUFF_LEN;

        if (IsReadable(hEntry, "EventEntry"))
        {
            err = spinNodeGetDisplayName(hEntry, entryName, &lenEntryName);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf("\t%s: unable to retrieve event entry by display name (error %d)...\n", entryName, err);
            }
        }
        else
        {
            continue;
        }
        // Retrieve enum entry integer value
        int64_t value = 0;

        err = spinEnumerationEntryGetIntValue(hEntry, &value);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("\t%s: unable to get event entry value (error %d)...\n", entryName, err);
            continue;
        }

        // Set integer value
        if (IsWritable(hEventSelector, "EventSelector"))
        {
            err = spinEnumerationSetIntValue(hEventSelector, value);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf("\t%s: unable to set event entry value (error %d)...\n", entryName, err);
                continue;
            }
        }
        else
        {
            err = SPINNAKER_ERR_ACCESS_DENIED;
            printf("\t%s: unable to set event entry value (error %d)...\n", entryName, err);
            continue;
        }

        // Retrieve event notification node (an enumeration node)
        spinNodeHandle hEventNotification = NULL;
        err = spinNodeMapGetNode(hNodeMap, "EventNotification", &hEventNotification);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("\t%s: unable to get entry from nodemap (error %d)...\n", entryName, err);
            continue;
        }

        spinNodeHandle hEventNotificationOff = NULL;
        int64_t eventNotificationOn = 0;

        if (IsReadable(hEventNotification, "EventNotification"))
        {
            err = spinEnumerationGetEntryByName(hEventNotification, "Off", &hEventNotificationOff);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf(
                    "Unable to set event notification to Off (entry 'Off' retrieval). Aborting with error "
                    "%d...\n\n",
                    err);
                continue;
            }
        }
        else
        {
            err = SPINNAKER_ERR_ACCESS_DENIED;
            printf(
                "Unable to read event notification mode. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
            continue;
        }

        if (IsReadable(hEventNotificationOff, "EventNotificationOff"))
        {
            err = spinEnumerationEntryGetIntValue(hEventNotificationOff, &eventNotificationOn);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf(
                    "Unable to set event notification to Off (entry int value retrieval). Aborting with error "
                    "%d...\n\n",
                    err);
                continue;
            }
        }
        else
        {
            err = SPINNAKER_ERR_ACCESS_DENIED;
            printf(
                "Unable to read event notification Off. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
            continue;
        }

        // Set event notification to Off
        if (IsWritable(hEventNotification, "EventNotification"))
        {
            err = spinEnumerationSetIntValue(hEventNotification, eventNotificationOn);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf(
                    "Unable to set event notification to Off (entry int value setting). Aborting with error "
                    "%d...\n\n",
                    err);
                continue;
            }
            printf("\t%s: disabled...\n", entryName);
        }
        else
        {
            err = SPINNAKER_ERR_ACCESS_DENIED;
            printf(
                "Unable to write to event notification. Aborting with error: %s [%d]\n\n", GetLastErrorMessage(), err);
            continue;
        }
    }

    return err;
}

// This function cleans up the example by turning auto gain back on
spinError ResetAutoGain(spinNodeMapHandle hNodeMap)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    //
    // Turn automatic gain back on
    //
    // *** NOTES ***
    // Automatic gain is turned on in order to return the camera to its
    // default state.
    //
    spinNodeHandle hGainAuto = NULL;
    spinNodeHandle hGainAutoContinuous = NULL;
    int64_t gainAutoContinuous = 0;

    err = spinNodeMapGetNode(hNodeMap, "GainAuto", &hGainAuto);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to disable automatic gain (node retrieval). Aborting with error %d...\n\n", err);
        return err;
    }

    if (IsReadable(hGainAuto, "GainAuto"))
    {
        err = spinEnumerationGetEntryByName(hGainAuto, "Continuous", &hGainAutoContinuous);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to enable automatic gain (enum entry retrieval). Aborting with error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "GainAuto");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    if (IsReadable(hGainAutoContinuous, "GainAutoContinuous"))
    {
        err = spinEnumerationEntryGetIntValue(hGainAutoContinuous, &gainAutoContinuous);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf(
                "Unable to enable automatic gain (enum entry int value retrieval). Aborting with error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("entry", "GainAuto 'Continuous'");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    if (IsWritable(hGainAuto, "GainAuto"))
    {
        err = spinEnumerationSetIntValue(hGainAuto, gainAutoContinuous);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to enable automatic gain (enum entry setting). Aborting with error %d...\n\n", err);
            return err;
        }

        printf("Automatic gain turned back on...\n\n");
    }
    else
    {
        PrintRetrieveNodeFailure("node", "GainAuto");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    return err;
}

// This function acquires 10 images from a device to trigger acquisition related
// nodemap events; please see Acquisition example for more in-depth comments on
// acquiring images.
spinError AcquireImages(spinCamera hCam, spinNodeMapHandle hNodeMap, spinNodeMapHandle hNodeMapTLDevice)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    printf("\n*** IMAGE ACQUISITION ***\n\n");

    // Set acquisition mode to continuous
    spinNodeHandle hAcquisitionMode = NULL;
    spinNodeHandle hAcquisitionModeContinuous = NULL;
    int64_t acquisitionModeContinuous = 0;

    // Retrieve enumeration node from nodemap
    err = spinNodeMapGetNode(hNodeMap, "AcquisitionMode", &hAcquisitionMode);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
        return err;
    }

    // Retrieve entry node from enumeration node
    if (IsReadable(hAcquisitionMode, "AcquisitionMode"))
    {
        err = spinEnumerationGetEntryByName(hAcquisitionMode, "Continuous", &hAcquisitionModeContinuous);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("entry", "AcquisitionMode");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    // Retrieve integer from entry node
    if (IsReadable(hAcquisitionModeContinuous, "AcquisitionModeContinuous"))
    {
        err = spinEnumerationEntryGetIntValue(hAcquisitionModeContinuous, &acquisitionModeContinuous);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("entry", "AcquisitionMode 'Continuous'");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }
    // Set integer as new value of enumeration node
    if (IsWritable(hAcquisitionMode, "AcquisitionMode"))
    {
        err = spinEnumerationSetIntValue(hAcquisitionMode, acquisitionModeContinuous);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("entry", "AcquisitionMode");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    printf("Acquisition mode set to continuous...\n");

    // Begin acquiring images
    err = spinCameraBeginAcquisition(hCam);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
        return err;
    }

    printf("Acquiring images...\n");

    // Retrieve device serial number for filename
    spinNodeHandle hDeviceSerialNumber = NULL;
    char deviceSerialNumber[MAX_BUFF_LEN];
    size_t lenDeviceSerialNumber = MAX_BUFF_LEN;

    err = spinNodeMapGetNode(hNodeMapTLDevice, "DeviceSerialNumber", &hDeviceSerialNumber);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        strcpy(deviceSerialNumber, "");
        lenDeviceSerialNumber = 0;
    }
    else
    {
        if (IsReadable(hDeviceSerialNumber, "DeviceSerialNumber"))
        {
            err = spinStringGetValue(hDeviceSerialNumber, deviceSerialNumber, &lenDeviceSerialNumber);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                strcpy(deviceSerialNumber, "");
                lenDeviceSerialNumber = 0;
            }
        }
        else
        {
            strcpy(deviceSerialNumber, "");
            lenDeviceSerialNumber = 0;
            PrintRetrieveNodeFailure("node", "DeviceSerialNumber");
        }
        printf("Device serial number retrieved as %s...\n", deviceSerialNumber);
    }
    printf("\n");

    // Retrieve, convert, and save images
    const unsigned int k_numImages = 10;
    unsigned int imageCnt = 0;

    //
    // Create Image Processor context for post processing images
    //
    spinImageProcessor hImageProcessor = NULL;
    err = spinImageProcessorCreate(&hImageProcessor);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to create image processor. Non-fatal error %d...\n\n", err);
    }

    //
    // Set default image processor color processing method
    //
    // *** NOTES ***
    // By default, if no specific color processing algorithm is set, the image
    // processor will default to NEAREST_NEIGHBOR method.
    //
    err = spinImageProcessorSetColorProcessing(hImageProcessor, SPINNAKER_COLOR_PROCESSING_ALGORITHM_HQ_LINEAR);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to set image processor color processing method. Non-fatal error %d...\n\n", err);
    }

    for (imageCnt = 0; imageCnt < k_numImages; imageCnt++)
    {
        // Retrieve next received image
        spinImage hResultImage = NULL;

        err = spinCameraGetNextImageEx(hCam, 1000, &hResultImage);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
            continue;
        }

        // Ensure image completion
        bool8_t isIncomplete = False;
        bool8_t hasFailed = False;

        err = spinImageIsIncomplete(hResultImage, &isIncomplete);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
            hasFailed = True;
        }

        // Check image for completion
        if (isIncomplete)
        {
            spinImageStatus imageStatus = SPINNAKER_IMAGE_STATUS_NO_ERROR;

            err = spinImageGetStatus(hResultImage, &imageStatus);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf("Unable to retrieve image status. Non-fatal error %d...\n\n", imageStatus);
            }
            else
            {
                printf("Image incomplete with image status %d...\n", imageStatus);
            }

            hasFailed = True;
        }

        // Release incomplete or failed image
        if (hasFailed)
        {
            err = spinImageRelease(hResultImage);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
            }

            continue;
        }

        //
        // Print image information; height and width recorded in pixels
        //
        // *** NOTES ***
        // Images have quite a bit of available metadata including things such
        // as CRC, image status, and offset values, to name a few.
        //
        size_t width = 0;
        size_t height = 0;

        printf("Grabbed image %d, ", imageCnt);

        // Retrieve image width
        err = spinImageGetWidth(hResultImage, &width);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("width = unknown, ");
        }
        else
        {
            printf("width = %u, ", (unsigned int)width);
        }

        // Retrieve image height
        err = spinImageGetHeight(hResultImage, &height);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("height = unknown\n");
        }
        else
        {
            printf("height = %u\n", (unsigned int)height);
        }

        //
        // Convert image to mono 8
        //
        // *** NOTES ***
        // Images not gotten from a camera directly must be created and
        // destroyed. This includes any image copies, conversions, or
        // otherwise. Basically, if the image was gotten, it should be
        // released, if it was created, it needs to be destroyed.
        //
        // Images can be converted between pixel formats by using the
        // appropriate enumeration value. Unlike the original image, the
        // converted one does not need to be released as it does not affect the
        // camera buffer.
        //
        // Optionally, the color processing algorithm can also be set using
        // the alternate spinImageConvertEx() function.
        //
        // *** LATER ***
        // The converted image was created, so it must be destroyed to avoid
        // memory leaks.
        //
        spinImage hConvertedImage = NULL;

        err = spinImageCreateEmpty(&hConvertedImage);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
            hasFailed = True;
        }

        err = spinImageProcessorConvert(hImageProcessor, hResultImage, hConvertedImage, PixelFormat_Mono8);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
            hasFailed = True;
        }

        //
        // Destroy converted image
        //
        // *** NOTES ***
        // Images that are created must be destroyed in order to avoid memory
        // leaks.
        //
        err = spinImageDestroy(hConvertedImage);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
        }

        //
        // Release image from camera
        //
        // *** NOTES ***
        // Images retrieved directly from the camera (i.e. non-converted
        // images) need to be released in order to keep from filling the
        // buffer.
        //
        err = spinImageRelease(hResultImage);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
        }
    }

    //
    // Destroy Image Processor context
    //
    // *** NOTES ***
    // Image processor context needs to be destroyed after all image processing
    // are complete to avoid memory leaks.
    //
    err = spinImageProcessorDestroy(hImageProcessor);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to destroy image processor. Non-fatal error %d...\n\n", err);
    }

    //
    // End acquisition
    //
    // *** NOTES ***
    // Ending acquisition appropriately helps ensure that devices clean up
    // properly and do not need to be power-cycled to maintain integrity.
    //
    err = spinCameraEndAcquisition(hCam);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Error: %s [%d]\n\n", GetLastErrorMessage(), err);
    }

    return err;
}

// This function prints the device information of the camera from the transport
// layer; please see NodeMapInfo_C example for more in-depth comments on
// printing device information from the nodemap.
spinError PrintDeviceInfo(spinNodeMapHandle hNodeMap)
{
    spinError err = SPINNAKER_ERR_SUCCESS;
    unsigned int i = 0;

    printf("\n*** DEVICE INFORMATION ***\n\n");

    // Retrieve device information category node
    spinNodeHandle hDeviceInformation = NULL;

    err = spinNodeMapGetNode(hNodeMap, "DeviceInformation", &hDeviceInformation);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve node. Non-fatal error %d...\n\n", err);
        return err;
    }

    // Retrieve number of nodes within device information node
    size_t numFeatures = 0;

    if (IsReadable(hDeviceInformation, "DeviceInformation"))
    {
        err = spinCategoryGetNumFeatures(hDeviceInformation, &numFeatures);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve number of nodes. Non-fatal error %d...\n\n", err);
            return err;
        }
    }
    else
    {
        PrintRetrieveNodeFailure("node", "DeviceInformation");
        return SPINNAKER_ERR_ACCESS_DENIED;
    }

    // Iterate through nodes and print information
    for (i = 0; i < numFeatures; i++)
    {
        spinNodeHandle hFeatureNode = NULL;

        err = spinCategoryGetFeatureByIndex(hDeviceInformation, i, &hFeatureNode);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve node. Non-fatal error %d...\n\n", err);
            continue;
        }

        spinNodeType featureType = UnknownNode;

        // get feature node name
        char featureName[MAX_BUFF_LEN];
        size_t lenFeatureName = MAX_BUFF_LEN;
        err = spinNodeGetName(hFeatureNode, featureName, &lenFeatureName);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            strcpy(featureName, "Unknown name");
        }

        if (IsReadable(hFeatureNode, featureName))
        {
            err = spinNodeGetType(hFeatureNode, &featureType);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                printf("Unable to retrieve node type. Non-fatal error %d...\n\n", err);
                continue;
            }
        }
        else
        {
            printf("%s: Node not readable\n", featureName);
            continue;
        }

        char featureValue[MAX_BUFF_LEN];
        size_t lenFeatureValue = MAX_BUFF_LEN;

        err = spinNodeToString(hFeatureNode, featureValue, &lenFeatureValue);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            strcpy(featureValue, "Unknown value");
        }

        printf("%s: %s\n", featureName, featureValue);
    }
    printf("\n");

    return err;
}

// This function acts as the body of the example; please see NodeMapInfo_C
// example for more in-depth comments on setting up cameras.
spinError RunSingleCamera(spinCamera hCam)
{
    spinError err = SPINNAKER_ERR_SUCCESS;

    // Retrieve TL device nodemap and print device information
    spinNodeMapHandle hNodeMapTLDevice = NULL;

    err = spinCameraGetTLDeviceNodeMap(hCam, &hNodeMapTLDevice);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve TL device nodemap (non-fatal error %d)...\n\n", err);
    }
    else
    {
        err = PrintDeviceInfo(hNodeMapTLDevice);
    }

    // Retrieve TL stream nodemap
    spinNodeMapHandle hNodeMapTLStream = NULL;

    err = spinCameraGetTLStreamNodeMap(hCam, &hNodeMapTLStream);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve TL stream nodemap (non-fatal error %d)...\n\n", err);
    }

    // Initialize camera
    err = spinCameraInit(hCam);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to initialize camera. Aborting with error %d...\n\n", err);
        return err;
    }

    // Retrieve GenICam nodemap
    spinNodeMapHandle hNodeMap = NULL;

    err = spinCameraGetNodeMap(hCam, &hNodeMap);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve GenICam nodemap. Aborting with error %d...\n\n", err);
        return err;
    }

    // Configure callbacks
    callbackArray callbackHandleArray;
    initArray(&callbackHandleArray, 1);

    err = ConfigureCallbacks(hNodeMap, &callbackHandleArray);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Configure event callbacks on remote device
    err = ConfigureEventCallbacks(hNodeMap, &callbackHandleArray);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Configure event callbacks on local device
    err = ConfigureEventCallbacks(hNodeMapTLDevice, &callbackHandleArray);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Configure event callbacks on local stream
    err = ConfigureEventCallbacks(hNodeMapTLStream, &callbackHandleArray);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Change height and gain to trigger callbacks
    err = ChangeHeightAndGain(hNodeMap);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Acquire images
    err = AcquireImages(hCam, hNodeMap, hNodeMapTLDevice);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Reset callbacks
    err = ResetCallbacks(&callbackHandleArray);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    freeArray(&callbackHandleArray);

    // Reset auto gain
    err = ResetAutoGain(hNodeMap);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Reset events on remote device
    err = ResetEvents(hNodeMap);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Reset events on local device
    err = ResetEvents(hNodeMapTLDevice);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Reset events on local stream
    err = ResetEvents(hNodeMapTLStream);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        return err;
    }

    // Deinitialize camera
    err = spinCameraDeInit(hCam);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to deinitialize camera. Non-fatal error %d...\n\n", err);
        return err;
    }

    return err;
}

// Example entry point; please see Enumeration_C example for more in-depth
// comments on preparing and cleaning up the system.
int main(/*int argc, char** argv*/)
{
    spinError errReturn = SPINNAKER_ERR_SUCCESS;
    spinError err = SPINNAKER_ERR_SUCCESS;
    unsigned int i = 0;

    // Print application build information
    printf("Application build date: %s %s \n\n", __DATE__, __TIME__);

    // Retrieve singleton reference to system object
    spinSystem hSystem = NULL;

    err = spinSystemGetInstance(&hSystem);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve system instance. Aborting with error %d...\n\n", err);
        return err;
    }

    // Print out current library version
    spinLibraryVersion hLibraryVersion;

    spinSystemGetLibraryVersion(hSystem, &hLibraryVersion);
    printf(
        "Spinnaker library version: %d.%d.%d.%d\n\n",
        hLibraryVersion.major,
        hLibraryVersion.minor,
        hLibraryVersion.type,
        hLibraryVersion.build);

    // Retrieve list of cameras from the system
    spinCameraList hCameraList = NULL;

    err = spinCameraListCreateEmpty(&hCameraList);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to create camera list. Aborting with error %d...\n\n", err);
        return err;
    }

    err = spinSystemGetCameras(hSystem, hCameraList);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve camera list. Aborting with error %d...\n\n", err);
        return err;
    }

    // Retrieve number of cameras
    size_t numCameras = 0;

    err = spinCameraListGetSize(hCameraList, &numCameras);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to retrieve number of cameras. Aborting with error %d...\n\n", err);
        return err;
    }

    printf("Number of cameras detected: %u\n\n", (unsigned int)numCameras);

    // Finish if there are no cameras
    if (numCameras == 0)
    {
        // Clear and destroy camera list before releasing system
        err = spinCameraListClear(hCameraList);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to clear camera list. Aborting with error %d...\n\n", err);
            return err;
        }

        err = spinCameraListDestroy(hCameraList);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to destroy camera list. Aborting with error %d...\n\n", err);
            return err;
        }

        // Release system
        err = spinSystemReleaseInstance(hSystem);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to release system instance. Aborting with error %d...\n\n", err);
            return err;
        }

        printf("Not enough cameras!\n");
        printf("Done! Press Enter to exit...\n");
        getchar();

        return -1;
    }

    // Run example on each camera
    for (i = 0; i < numCameras; i++)
    {
        printf("\nRunning example for camera %d...\n", i);

        // Select camera
        spinCamera hCamera = NULL;

        err = spinCameraListGet(hCameraList, i, &hCamera);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            printf("Unable to retrieve camera from list. Aborting with error %d...\n\n", err);
            errReturn = err;
        }
        else
        {
            // Run example
            err = RunSingleCamera(hCamera);
            if (err != SPINNAKER_ERR_SUCCESS)
            {
                errReturn = err;
            }
        }

        // Release camera
        err = spinCameraRelease(hCamera);
        if (err != SPINNAKER_ERR_SUCCESS)
        {
            errReturn = err;
        }

        printf("Camera %d example complete...\n\n", i);
    }

    // Clear and destroy camera list before releasing system
    err = spinCameraListClear(hCameraList);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to clear camera list. Aborting with error %d...\n\n", err);
        return err;
    }

    err = spinCameraListDestroy(hCameraList);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to destroy camera list. Aborting with error %d...\n\n", err);
        return err;
    }

    // Release system
    err = spinSystemReleaseInstance(hSystem);
    if (err != SPINNAKER_ERR_SUCCESS)
    {
        printf("Unable to release system instance. Aborting with error %d...\n\n", err);
        return err;
    }

    printf("\nDone! Press Enter to exit...\n");
    getchar();

    return errReturn;
}
