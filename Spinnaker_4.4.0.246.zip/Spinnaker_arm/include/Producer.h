//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

#ifndef FLIR_SPINNAKER_PRODUCER_H
#define FLIR_SPINNAKER_PRODUCER_H

#include "Interface/IProducer.h"

namespace Spinnaker
{
    // Forward declaration of implementation class
    class IProducerImpl;

    /**
     * @defgroup SpinnakerClasses Spinnaker Classes
     */
    /**@{*/

    /**
     * @defgroup Producer_h Producer Class
     */
    /**@{*/

    /**
     * @brief The producer object is used to retrieve the list of interfaces and cameras available.
     */

    class Producer : public IProducer
    {
        friend class SystemImpl;
        friend class InterfaceImpl;

      public:
        /**
         * Default destructor.
         */
        virtual ~Producer(void);

        /**
         * Get file path to the producer CTI file.
         *
         * @return std::string that represents the producer CTI file path.
         */
        virtual GenICam::gcstring GetProducerFilePath() const;

        /**
         * Returns a list of interfaces available on the producer.  This call
         * returns GigE and Usb2 and Usb3 interfaces. Note that on MacOS only
         * active GigE interfaces will be stored in the returned InterfaceList.
         *
         * @see UpdateInterfaceList()
         *
         * @param updateInterface Determines whether or not UpdateInterfaceList() is called before getting available
         * interfaces
         *
         * @return An InterfaceList object that contains a list of all interfaces.
         */
        virtual InterfaceList GetInterfaces(bool updateInterface = true);

        /**
         * Updates the list of interfaces on the producer. If desired, local copies
         * of InterfaceList should be updated by calling GetInterfaces.
         *
         * @see GetInterfaces()
         */
        virtual bool UpdateInterfaceList();

        /**
         * Returns a list of cameras that are available on the producer.  This call
         * returns both GigE Vision and Usb3 Vision cameras from all interfaces.
         * The camera list object will reference count the cameras it returns.  It
         * is important that the camera list is destroyed or is cleared before calling
         * system->ReleaseInstance() or else the call to system->ReleaseInstance()
         * will result in an error message thrown that a reference to the camera
         * is still held.
         *
         * @see ReleaseInstance()
         *
         * @see CameraList::Clear()
         *
         * @param updateInterfaces Determines whether or not updateInterfaceList() is called before getting cameras
         *                         from available interfaces on the producer
         *
         * @param updateCameras Determines whether or not UpdateCameras() is called before getting cameras from
         *                      available interfaces on the producer
         *
         * @return An CameraList object that contains a list of all cameras.
         */
        virtual CameraList GetCameras(bool updateInterfaces = true, bool updateCameras = true);

        /**
         * Updates the list of cameras on the producer. Note that Producer::GetCameras()
         * internally calls UpdateCameras() for each interface it enumerates.  If the list
         * changed between this call and the last time UpdateCameras was called then the return
         * value will be true, otherwise it is false.
         *
         * @see GetCameras()
         *
         * @param updateInterfaces Determines whether or not UpdateInterfaceList() is called before updating cameras
         *                         for available interfaces on the producer
         *
         * @return True if cameras changed on interface and false otherwise.
         */
        virtual bool UpdateCameras(bool updateInterfaces = true);

        /**
         * Gets a nodeMap that is generated from a GenICam
         * XML file for the producer.
         *
         * @return  A reference to a INodeMap object.
         */
        virtual GenApi::INodeMap& GetTLNodeMap() const;

        /**
         * Registers an event handler for the producer.
         *
         * @see SystemEventHandler
         * @see InterfaceEventHandler
         *
         * @param evtHandlerToRegister The event handler to register for the producer
         * @param updateInterface Determines whether or not UpdateInterfaceList() is called before registering event for
         *        available interfaces on the producer
         *
         */
        void RegisterEventHandler(EventHandler& evtHandlerToRegister, bool updateInterface = false);

        /**
         * Unregisters an event handler for the producer.
         *
         * @see SystemEventHandler
         * @see InterfaceEventHandler
         *
         * @param evtHandlerToUnregister The interface event handler to unregister from the producer
         *
         */
        void UnregisterEventHandler(EventHandler& evtHandlerToUnregister);

        /**
         * Registers a logging event.
         *
         * @see LoggingEventHandler
         *
         * @param handler The logging event handler to register
         */
        virtual void RegisterLoggingEventHandler(LoggingEventHandler& handler);

        /**
         * Unregisters all previously registered logging events.
         *
         */
        virtual void UnregisterAllLoggingEventHandlers();

        /**
         * Unregisters a logging event.
         *
         * @see LoggingEventHandler
         *
         * @param handler The logging event handler to unregister
         */
        virtual void UnregisterLoggingEventHandler(LoggingEventHandler& handler);

        /**
         * Sets a threshold priority level for logging event. Logging events
         * below such level will not trigger callbacks.
         *
         * Spinnaker uses multiple levels of logging:
         *  - Fatal     - failures that are non-recoverable without user intervention.
         *  - Error     - failures that may or may not be recoverable without user
         *                intervention (use case dependent).
         *  - Warning   - failures that are recoverable without user intervention.
         *  - Notice    - information about events such as camera arrival and removal,
         *                initialization and deinitialization, starting and stopping image
         *                acquisition, and feature modification.
         *  - Info      - information about recurring events that are generated regularly
         *                such as information on individual images.
         *  - Debug     - information that can be used to troubleshoot the producer.
         *
         *
         * @see SpinnakerLogLevel
         *
         * @param level The threshold level
         */
        virtual void SetLoggingCallbackPriorityLevel(SpinnakerLogLevel level);

        /**
         * Retrieves the current logging event priority level.
         *
         * Spinnaker uses multiple levels of logging:
         *  - Fatal     - failures that are non-recoverable without user intervention.
         *  - Error     - failures that may or may not be recoverable without user
         *                intervention (use case dependent).
         *  - Warning   - failures that are recoverable without user intervention.
         *  - Notice    - information about events such as camera arrival and removal,
         *                initialization and deinitialization, starting and stopping image
         *                acquisition, and feature modification.
         *  - Info      - information about recurring events that are generated regularly
         *                such as information on individual images.
         *  - Debug     - information that can be used to troubleshoot the producer.
         *
         * @see SpinnakerLogLevel
         *
         * @return Level The threshold level
         */
        virtual SpinnakerLogLevel GetLoggingCallbackPriorityLevel();

        /**
         * Checks if the producer is in use by any interface objects.
         *
         * @return Returns true if the producer is in use and false otherwise.
         */
        virtual bool IsInterfaceInUse();

        /**
         * Checks if the producer is in use by any camera objects.
         *
         * @return Returns true if the producer is in use and false otherwise.
         */
        virtual bool IsCameraInUse();

        /**
         * Broadcast an Action Command to all devices on producer
         *
         * @param deviceKey The Action Command's device key
         * @param groupKey The Action Command's group key
         * @param groupMask The Action Command's group mask
         * @param actionTime (Optional) Time when to assert a future action. Zero means immediate action.
         * @param pResultSize (Optional) The number of results in the results array. The value passed should be equal to
         * the expected number of devices that acknowledge the command. Returns the number of received results. If this
         * parameter is 0 or NULL, the function will return as soon as the command has been broadcasted.
         * @param results (Optional) An Array with *pResultSize elements to hold the action command result status. The
         * buffer is filled starting from index 0. If received results are less than expected number of devices that
         * acknowledge the command, remaining results are not changed. If received results are more than expected number
         * of devices that acknowledge the command, extra results are ignored and not appended to array. This parameter
         * is ignored if pResultSize is 0. Thus this parameter can be NULL if pResultSize is 0 or NULL.
         *
         */
        virtual void SendActionCommand(
            unsigned int deviceKey,
            unsigned int groupKey,
            unsigned int groupMask,
            unsigned long long actionTime = 0,
            bool requestAck = false,
            unsigned int* pResultSize = 0,
            ActionCommandResult results[] = NULL);

      protected:
        /**
         * Default constructor.
         */
        Producer();

        /**
         * Stops the internal event handler for the system.
         */
        virtual void StopInternalEventHandler();

        /**
         * Releases the interfaces that are enumerated from this producer.
         */
        void ReleaseInstance();

      private:
        /**
         * Copy constructor.
         */
        Producer(const Producer&);

        /**
         * Assignment operator.
         */
        Producer& operator=(const Producer&);

        /**
         * Internal use only.
         */
        IProducerImpl* m_pProducerImpl;
    };

    /**@}*/

    /**@}*/
} // namespace Spinnaker

#endif // FLIR_SPINNAKER_PRODUCER_H
