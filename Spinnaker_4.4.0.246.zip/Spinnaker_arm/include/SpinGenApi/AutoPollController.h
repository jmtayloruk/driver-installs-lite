//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

#ifndef SPINNAKER_GENAPI_AUTOPOLLCONTROLLER_H
#define SPINNAKER_GENAPI_AUTOPOLLCONTROLLER_H

#include "NodeMap.h"
#include "SpinnakerPlatform.h"

#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <atomic>

namespace Spinnaker
{
    namespace GenApi
    {
        /**
         *  @defgroup SpinnakerGenApiClasses Spinnaker GenApi Classes
         */
        /**@{*/

        /**
         *  @defgroup AutoPollController_h AutoPollController Class
         */
        /**@{*/

        /**
         * @brief Auto polling controller for NodeMap.
         */
        class SPINNAKER_API AutoPollController
        {
          public:
            AutoPollController(NodeMap& owner);

            ~AutoPollController();

            void Start(int64_t intervalMs);

            void Stop();

          private:
            void StopLocked();

            void Run();

            NodeMap& m_nodeMap;
            std::atomic<bool> m_running{false};
            int64_t m_intervalMs = 0;

            std::thread m_thread;
            std::mutex m_mutex;
            std::condition_variable m_cv;
        };

        /**@}*/
        /**@}*/
    } // namespace GenApi
} // namespace Spinnaker

#endif // SPINNAKER_GENAPI_AUTOPOLLCONTROLLER_H