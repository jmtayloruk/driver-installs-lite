//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

#ifndef FLIR_SPINNAKER_IPRODUCER_H
#define FLIR_SPINNAKER_IPRODUCER_H

#include "SpinnakerPlatform.h"
#include "SpinnakerDefs.h"
#include "CameraList.h"
#include "InterfaceList.h"
#include "TransportLayerSystem.h"
#include "EventHandler.h"

namespace Spinnaker
{
    // Forward declaration of implementation class
    class LoggingEventHandler;

    /**
     * @defgroup SpinnakerClasses Spinnaker Classes
     */
    /**@{*/

    /**
     * @defgroup IProducer_h IProducer Class
     */
    /**@{*/

    /**
     * @brief The interface file for Producer.
     */

    class SPINNAKER_API IProducer
    {
        friend class SystemImpl;

      public:
        virtual ~IProducer(){};

        virtual GenICam::gcstring GetProducerFilePath() const = 0;

        virtual InterfaceList GetInterfaces(bool updateInterface = true) = 0;
        virtual CameraList GetCameras(bool updateInterface = true, bool updateCameras = true) = 0;
        virtual bool UpdateCameras(bool updateInterface = true) = 0;
        virtual bool UpdateInterfaceList() = 0;

        virtual GenApi::INodeMap& GetTLNodeMap() const = 0;

        virtual void RegisterEventHandler(EventHandler& evtHandlerToRegister, bool updateInterface = false) = 0;
        virtual void UnregisterEventHandler(EventHandler& evtHandlerToUnregister) = 0;

        virtual void RegisterLoggingEventHandler(LoggingEventHandler& handler) = 0;
        virtual void UnregisterAllLoggingEventHandlers() = 0;
        virtual void UnregisterLoggingEventHandler(LoggingEventHandler& handler) = 0;
        virtual void SetLoggingCallbackPriorityLevel(SpinnakerLogLevel level) = 0;
        virtual SpinnakerLogLevel GetLoggingCallbackPriorityLevel() = 0;

        virtual bool IsInterfaceInUse() = 0;
        virtual bool IsCameraInUse() = 0;
        virtual void SendActionCommand(
            unsigned int deviceKey,
            unsigned int groupKey,
            unsigned int groupMask,
            unsigned long long actionTime,
            bool requestAck,
            unsigned int* pResultSize,
            ActionCommandResult results[] = NULL) = 0;

        // Gets vital system information without connecting to the XML through transport layer specific bootstrap
        // registers.
        TransportLayerSystem TLSystem;

      protected:
        friend class ProducerInternal;
        friend class ProducerListImpl;
        friend class InterfaceImpl;
        struct ProducerData; // Forward declaration
        ProducerData* m_pProducerData;

        IProducer(){};
        IProducer(const IProducer&){};
        IProducer& operator=(const IProducer&);

        virtual void StopInternalEventHandler() = 0;
        virtual void ReleaseInstance() = 0;
    };

    /**@}*/

    /**@}*/
} // namespace Spinnaker

#endif // FLIR_SPINNAKER_IPRODUCER_H
