//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

#ifndef FLIR_SPINNAKER_IPRODUCERLIST_H
#define FLIR_SPINNAKER_IPRODUCERLIST_H

#include "ProducerPtr.h"

namespace Spinnaker
{
    class ProducerList;

    /**
     * @defgroup SpinnakerClasses Spinnaker Classes
     */

    /**@{*/

    /**
     * @defgroup IProducerList_h IProducerList Class
     */

    /**@{*/

    /**
     * @brief The interface file for ProducerList class.
     */

    class SPINNAKER_API IProducerList
    {
      public:
        virtual ~IProducerList(void){};
        virtual ProducerPtr operator[](unsigned int index) = 0;
        virtual unsigned int GetSize() const = 0;
        virtual ProducerPtr GetByIndex(unsigned int index) const = 0;
        virtual void Clear() = 0;
        virtual void Add(ProducerPtr prod) = 0;
        virtual void Remove(ProducerPtr prod) = 0;
        virtual void Append(const ProducerList* list) = 0;

      protected:
        friend class ProducerListImpl;
        struct ProducerListData; // Forward declaration
        ProducerListData* m_pProducerListData;

        IProducerList(void){};
        IProducerList(const IProducerList&){};
        IProducerList& operator=(const IProducerList&);
    };

    /**@}*/

    /**@}*/
} // namespace Spinnaker

#endif // FLIR_SPINNAKER_IPRODUCERLIST_H