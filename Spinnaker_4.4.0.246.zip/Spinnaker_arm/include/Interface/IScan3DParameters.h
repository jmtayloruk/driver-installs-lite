//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

/* Auto-generated file. Do not modify. */

#ifndef FLIR_SPINNAKER_ISCAN3DPARAMETERS_H
#define FLIR_SPINNAKER_ISCAN3DPARAMETERS_H

#include "SpinGenApi/GCTypes.h"
#include "SpinGenApi/INodeMap.h"
#include "CameraDefs.h"

namespace Spinnaker
{
    /**
    * @defgroup SpinnakerClasses Spinnaker Classes
    */
    /**@{*/

    /**
    * @defgroup IScan3DParameters_h IScan3DParameters Class
    */
    /**@{*/

    /**
    *@brief The Interface file for Scan3DParameters data.
    */

    class SPINNAKER_API IScan3DParameters
    {
    public:
        virtual ~IScan3DParameters(){};

        virtual void SetScan3DParameters(GenApi::INodeMap & pNodeMap) = 0;

        virtual float64_t GetFocalLength() const = 0;
        virtual float64_t GetBaseline() const = 0;
        virtual float64_t GetPrincipalPointU() const = 0;
        virtual float64_t GetPrincipalPointV() const = 0;
        virtual Scan3dDistanceUnitEnums GetDistanceUnit() const = 0;
        virtual Scan3dCoordinateSystemEnums GetCoordinateSystem() const = 0;
        virtual Scan3dOutputModeEnums GetOutputMode() const = 0;
        virtual Scan3dCoordinateSystemReferenceEnums GetCoordinateSystemReference() const = 0;
        virtual Scan3dCoordinateSelectorEnums GetCoordinateSelector() const = 0;
        virtual Scan3dCoordinateTransformSelectorEnums GetCoordinateTransformSelector() const = 0;
        virtual float64_t GetTransformValue() const = 0;
        virtual Scan3dCoordinateReferenceSelectorEnums GetCoordinateReferenceSelector() const = 0;
        virtual float64_t GetCoordinateReferenceValue() const = 0;

        virtual void SetFocalLength(float64_t value) = 0;
        virtual void SetBaseline(float64_t value) = 0;
        virtual void SetPrincipalPointU(float64_t value) = 0;
        virtual void SetPrincipalPointV(float64_t value) = 0;
        virtual void SetDistanceUnit(Scan3dDistanceUnitEnums value) = 0;
        virtual void SetCoordinateSystem(Scan3dCoordinateSystemEnums value) = 0;
        virtual void SetOutputMode(Scan3dOutputModeEnums value) = 0;
        virtual void SetCoordinateSystemReference(Scan3dCoordinateSystemReferenceEnums value) = 0;
        virtual void SetCoordinateSelector(Scan3dCoordinateSelectorEnums value) = 0;
        virtual void SetCoordinateTransformSelector(Scan3dCoordinateTransformSelectorEnums value) = 0;
        virtual void SetTransformValue(float64_t value) = 0;
        virtual void SetCoordinateReferenceSelector(Scan3dCoordinateReferenceSelectorEnums value) = 0;
        virtual void SetCoordinateReferenceValue(float64_t value) = 0;

    protected:
        friend class Scan3DParametersImpl;
        friend class ImageImpl;
        struct Scan3DParametersData; // forward declaration
        Scan3DParametersData* m_pScan3DParametersData;
        IScan3DParameters() {};

    };
    /**@}*/

    /**@}*/

}
#endif // FLIR_SPINNAKER_ISCAN3DPARAMETERS_H