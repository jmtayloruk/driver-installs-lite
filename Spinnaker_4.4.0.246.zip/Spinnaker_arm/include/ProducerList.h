//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

#ifndef FLIR_SPINNAKER_PRODUCERLIST_H
#define FLIR_SPINNAKER_PRODUCERLIST_H

#include "Interface/IProducerList.h"

namespace Spinnaker
{
    /**
     * @defgroup SpinnakerClasses Spinnaker Classes
     */

    /**@{*/

    /**
     * @defgroup ProducerList_h ProducerList Class
     */

    /**@{*/

    /**
     * @brief A list of the available producers on the system.
     */

    class SPINNAKER_API ProducerList : public IProducerList
    {
      public:
        /*
         * Default Constructor
         */
        ProducerList(void);

        /*
         * Virtual Destructor
         */
        virtual ~ProducerList(void);

        /*
         * Copy Constructor
         */
        ProducerList(const ProducerList& prod);

        /**
         * Assignment operator.
         */
        ProducerList& operator=(const ProducerList& prod);

        /**
         * Array subscription operators
         */
        ProducerPtr operator[](unsigned int index);

        /**
         * Returns the size of the producer list.  The size is the number
         * of Producer objects stored in the list.
         *
         * @return An integer that represents the list size.
         */
        unsigned int GetSize() const;

        /**
         * Returns a pointer to an Producer object at the "index".
         *
         * @param index The index at which to retrieve the Producer object
         *
         * @return A pointer to an Producer object.
         */
        ProducerPtr GetByIndex(unsigned int index) const;

        /**
         * Returns a pointer to a producer object with the specified producer identifier. This
         * function will return a NULL ProducerPtr if no matching producer identifier is found.
         *
         * @param producerID The unique producer identifier of the producer object to retrieve
         *
         * @return A pointer to an Producer object.
         */
        ProducerPtr GetByProducerID(GenICam::gcstring producerID) const;

        /**
         * Clears the list of producers and destroys their corresponding objects.
         * It is important to first make sure there are no referenced cameras still
         * in use before calling Clear().  If a camera on any of the producers is still
         * in use this function will throw an exception.
         *
         */
        void Clear();

        /**
         * Adds a copy of an producer object.
         *
         * @param prod An producer object to be added to this list.
         */
        void Add(ProducerPtr prod);

        /**
         * Removes all occurences of an producer that is pointed to by the input producer
         * pointer and destroys its corresponding reference counted object. This function will
         * throw a Spinnaker exception with SPINNAKER_ERR_NOT_AVAILABLE error if no matching
         * producer is found.
         *
         * @param prod Pointer to the producer that is to be removed
         */
        void Remove(ProducerPtr prod);

        /**
         * Appends a copy of the producer list.
         *
         * @param list Another ProducerList object, whose elements are added to this list.
         */
        void Append(const ProducerList* list);

      protected:
        friend class SystemImpl;
        friend class ProducerImpl;
    };

    /**@}*/

    /**@}*/
} // namespace Spinnaker

#endif // FLIR_SPINNAKER_PRODUCERLIST_H