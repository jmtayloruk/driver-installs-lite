//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

/* Auto-generated file. Do not modify. */

#ifndef FLIR_SPINNAKER_SCAN3DPARAMETERS_H
#define FLIR_SPINNAKER_SCAN3DPARAMETERS_H

#include "Interface/IScan3DParameters.h"
#include <map>

namespace Spinnaker
{
    /**
    * @defgroup SpinnakerClasses Spinnaker Classes
    */
    /**@{*/

    /**
    * @defgroup Scan3DParameters_h Scan3DParameters Class
    */
    /**@{*/

    /**
    * @brief Container for 3D scan calibration parameters used in stereo processing.
    *
    * The Scan3DParameters class provides access to camera calibration parameters required for
    * stereo image processing, including computing 3D point clouds from disparity images.
    * This is the primary API for working with stereo camera parameters.
    *
    * **Key Parameters:**
    * - Baseline: Physical distance between the two cameras (in meters)
    * - Focal Length: Focal length in pixels
    * - Principal Point (U, V): Optical center of the camera
    * - Coordinate Scale/Offset: Transform disparity values to world coordinates
    * - Coordinate Selector: Select coordinate axis (X/Y/Z or CoordinateA/B/C)
    * - Invalid Data: Identify and handle invalid pixels in disparity images
    *
    * **Coordinate-Dependent Parameters:**
    * Some parameters (CoordinateOffset, CoordinateScale, InvalidDataFlag,
    * InvalidDataValue, AxisMin, AxisMax) vary per coordinate axis. Set the
    * CoordinateSelector before accessing these parameters to specify which
    * coordinate axis (A/B/C) you want to configure.
    *
    * **Common Usage Pattern:**
    * @code{.cpp}
    * // Option 1: Create and auto-populate from camera
    * Scan3DParameters scan3dParams(pCamera->GetNodeMap());
    * 
    * // Option 2: Create empty and populate later
    * Scan3DParameters scan3dParams;
    * scan3dParams.SetScan3DParameters(pCamera->GetNodeMap());  // Read from camera
    * 
    * // Option 3: Set manually
    * scan3dParams.SetBaseline(0.12f);                // 120mm baseline
    * scan3dParams.SetFocalLength(1500.0f);           // focal length in pixels
    * scan3dParams.SetPrincipalPointU(640.0f);        // image center U
    * scan3dParams.SetPrincipalPointV(512.0f);        // image center V
    * 
    * // Set coordinate-dependent parameters for Z-axis (CoordinateC)
    * scan3dParams.SetCoordinateSelector(Scan3dCoordinateSelector_CoordinateC);
    * scan3dParams.SetCoordinateOffset(0.0f);
    * scan3dParams.SetCoordinateScale(1.0f);
    * scan3dParams.SetInvalidDataFlag(true);
    * scan3dParams.SetInvalidDataValue(-10000.0f);
    * 
    * // Use with ImageUtilityStereo functions
    * PointCloudData pointCloud = ImageUtilityStereo::ComputePointCloud(
    *     disparityImage, rectifiedImage, pointCloudParams, scan3dParams);
    * @endcode
    *
    * @see ImageUtilityStereo for stereo processing functions
    * @see StereoCameraParameters for legacy API (deprecated)
    * @see ToStereoCameraParameters() for backward compatibility conversion
    * @see FromStereoCameraParameters() for legacy parameter import
    *
    * @note This class replaces the deprecated StereoCameraParameters struct.
    *       Use ToStereoCameraParameters() and FromStereoCameraParameters() for
    *       migration and backward compatibility.
    *
    * @note For cameras with coordinate selector support, coordinate-dependent
    *       parameters are stored per axis. Always set CoordinateSelector before
    *       accessing these parameters to ensure you're working with the correct axis.
    */

    /**
    * @brief Structure containing all coordinate-dependent parameters for a single axis.
    *
    * This structure groups together all parameters that vary per coordinate (A, B, C).
    * Use with GetCoordinateParams() and SetCoordinateParams() for efficient batch operations.
    */
    struct SPINNAKER_API CoordinateDependentParams
    {
        float64_t invalidDataValue;   ///< Value identifying non-valid pixels
        float64_t coordinateOffset;    ///< Offset for coordinate transformation
        float64_t coordinateScale;     ///< Scale factor for coordinate transformation
        bool invalidDataFlag;          ///< Enable/disable invalid data flagging
        float64_t axisMin;            ///< Minimum valid coordinate value
        float64_t axisMax;            ///< Maximum valid coordinate value
    };

    class SPINNAKER_API Scan3DParameters: public IScan3DParameters
    {
    public:
        Scan3DParameters();

        Scan3DParameters(GenApi::INodeMap & nodeMap);

        Scan3DParameters(const Scan3DParameters& src);

        virtual ~Scan3DParameters(void);

        Scan3DParameters& operator=(const Scan3DParameters& scan);

        void SetScan3DParameters(GenApi::INodeMap & pNodeMap);

        /**
         * Description: Displays the focal length of the camera in pixels.
         * Visibility: 
         */
        float64_t GetFocalLength() const;

        /**
         * Description: Displays the baseline in meters as the physical distance of two image sensors in the stereo camera.
         * Visibility: 
         */
        float64_t GetBaseline() const;

        /**
         * Description: Displays the value of the horizontal position of the principal point, relative to the region origin, i.e. OffsetX .
         * Visibility: 
         */
        float64_t GetPrincipalPointU() const;

        /**
         * Description: Displays the value of the vertical position of the principal point, relative to the region origin, i.e. OffsetY.
         * Visibility: 
         */
        float64_t GetPrincipalPointV() const;

        /**
         * Description: Specifies the unit used when delivering (calibrated) distance data.
         * Visibility: Expert
         */
        Scan3dDistanceUnitEnums GetDistanceUnit() const;

        /**
         * Description: Specifies the Coordinate system to use for the device.
         * Visibility: Expert
         */
        Scan3dCoordinateSystemEnums GetCoordinateSystem() const;

        /**
         * Description: Controls the Calibration and data organization of the device and  the coordinates transmitted.
         * Visibility: Expert
         */
        Scan3dOutputModeEnums GetOutputMode() const;

        /**
         * Description: Defines coordinate system reference location.
         * Visibility: Expert
         */
        Scan3dCoordinateSystemReferenceEnums GetCoordinateSystemReference() const;

        /**
         * Description: Selects the individual coordinates in the vectors for 3D information/transformation.
         * Visibility: Expert
         */
        Scan3dCoordinateSelectorEnums GetCoordinateSelector() const;

        /**
         * Description: Sets the index to read/write a coordinate transform value.
         * Visibility: Expert
         */
        Scan3dCoordinateTransformSelectorEnums GetCoordinateTransformSelector() const;

        /**
         * Description: Specifies the transform value selected. For translations (Scan3dCoordinateTransformSelector = TranslationX/Y/Z) it is expressed in the distance unit of the system, for rotations (Scan3dCoordinateTransformSelector =RotationX/Y/Z) in degrees.
         * Visibility: Expert
         */
        float64_t GetTransformValue() const;

        /**
         * Description: Sets the index to read a coordinate system reference value defining the transform of a point from the current (Anchor or Transformed) system to the reference system.
         * Visibility: Expert
         */
        Scan3dCoordinateReferenceSelectorEnums GetCoordinateReferenceSelector() const;

        /**
         * Description: Returns the reference value selected. Reads the value of a rotation or translation value for the current (Anchor or Transformed) coordinate system transformation to the Reference system.
         * Visibility: Expert
         */
        float64_t GetCoordinateReferenceValue() const;

        /**
         * Description: Displays the focal length of the camera in pixels.
         * Visibility: 
         */
        void SetFocalLength(float64_t value);

        /**
         * Description: Displays the baseline in meters as the physical distance of two image sensors in the stereo camera.
         * Visibility: 
         */
        void SetBaseline(float64_t value);

        /**
         * Description: Displays the value of the horizontal position of the principal point, relative to the region origin, i.e. OffsetX .
         * Visibility: 
         */
        void SetPrincipalPointU(float64_t value);

        /**
         * Description: Displays the value of the vertical position of the principal point, relative to the region origin, i.e. OffsetY.
         * Visibility: 
         */
        void SetPrincipalPointV(float64_t value);

        /**
         * Description: Specifies the unit used when delivering (calibrated) distance data.
         * Visibility: Expert
         */
        void SetDistanceUnit(Scan3dDistanceUnitEnums value);

        /**
         * Description: Specifies the Coordinate system to use for the device.
         * Visibility: Expert
         */
        void SetCoordinateSystem(Scan3dCoordinateSystemEnums value);

        /**
         * Description: Controls the Calibration and data organization of the device and  the coordinates transmitted.
         * Visibility: Expert
         */
        void SetOutputMode(Scan3dOutputModeEnums value);

        /**
         * Description: Defines coordinate system reference location.
         * Visibility: Expert
         */
        void SetCoordinateSystemReference(Scan3dCoordinateSystemReferenceEnums value);

        /**
         * Description: Selects the individual coordinates in the vectors for 3D information/transformation.
         * Visibility: Expert
         */
        void SetCoordinateSelector(Scan3dCoordinateSelectorEnums value);

        /**
         * Description: Sets the index to read/write a coordinate transform value.
         * Visibility: Expert
         */
        void SetCoordinateTransformSelector(Scan3dCoordinateTransformSelectorEnums value);

        /**
         * Description: Specifies the transform value selected. For translations (Scan3dCoordinateTransformSelector = TranslationX/Y/Z) it is expressed in the distance unit of the system, for rotations (Scan3dCoordinateTransformSelector =RotationX/Y/Z) in degrees.
         * Visibility: Expert
         */
        void SetTransformValue(float64_t value);

        /**
         * Description: Sets the index to read a coordinate system reference value defining the transform of a point from the current (Anchor or Transformed) system to the reference system.
         * Visibility: Expert
         */
        void SetCoordinateReferenceSelector(Scan3dCoordinateReferenceSelectorEnums value);

        /**
         * Description: Returns the reference value selected. Reads the value of a rotation or translation value for the current (Anchor or Transformed) coordinate system transformation to the Reference system.
         * Visibility: Expert
         */
        void SetCoordinateReferenceValue(float64_t value);

        /**
         * @name Enhanced Coordinate-Dependent Parameter Access
         * @{
         * These methods provide direct access to coordinate-specific parameters without
         * requiring manual selector changes. The coordinate parameter defaults to CoordinateC.
         */

        /**
         * Description: Value which identifies a non-valid pixel if Scan3dInvalidDataFlag is enabled.
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         * @return The parameter value for the specified coordinate
         */
        float64_t GetInvalidDataValue(Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC) const;

        /**
         * Description: Offset when transforming a pixel from relative coordinates to world coordinates. In terms of disparity computation, it is equivalent to minimum disparity.
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         * @return The parameter value for the specified coordinate
         */
        float64_t GetCoordinateOffset(Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC) const;

        /**
         * Description: Enables the definition of a non-valid flag value in the data stream.
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         * @return The parameter value for the specified coordinate
         */
        bool GetInvalidDataFlag(Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC) const;

        /**
         * Description: Displays the Scale factor when transforming a pixel from relative coordinates to world coordinates.
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         * @return The parameter value for the specified coordinate
         */
        float64_t GetCoordinateScale(Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC) const;

        /**
         * Description: Minimum valid transmitted coordinate value of the selected Axis.
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         * @return The parameter value for the specified coordinate
         */
        float64_t GetAxisMin(Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC) const;

        /**
         * Description: Maximum valid transmitted coordinate value of the selected Axis.
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         * @return The parameter value for the specified coordinate
         */
        float64_t GetAxisMax(Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC) const;

        /**
         * Description: Value which identifies a non-valid pixel if Scan3dInvalidDataFlag is enabled.
         * @param value The value to set
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         */
        void SetInvalidDataValue(float64_t value, Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC);

        /**
         * Description: Offset when transforming a pixel from relative coordinates to world coordinates. In terms of disparity computation, it is equivalent to minimum disparity.
         * @param value The value to set
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         */
        void SetCoordinateOffset(float64_t value, Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC);

        /**
         * Description: Enables the definition of a non-valid flag value in the data stream.
         * @param value The value to set
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         */
        void SetInvalidDataFlag(bool value, Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC);

        /**
         * Description: Displays the Scale factor when transforming a pixel from relative coordinates to world coordinates.
         * @param value The value to set
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         */
        void SetCoordinateScale(float64_t value, Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC);

        /**
         * Description: Minimum valid transmitted coordinate value of the selected Axis.
         * @param value The value to set
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         */
        void SetAxisMin(float64_t value, Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC);

        /**
         * Description: Maximum valid transmitted coordinate value of the selected Axis.
         * @param value The value to set
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         */
        void SetAxisMax(float64_t value, Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC);

        /**
         * Get all coordinate-dependent parameters for a specific coordinate axis.
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         * @return Structure containing all coordinate-dependent parameters
         */
        CoordinateDependentParams GetCoordinateParams(Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC) const;

        /**
         * Set all coordinate-dependent parameters for a specific coordinate axis.
         * @param params Structure containing all coordinate-dependent parameters
         * @param coordinate The coordinate axis (defaults to CoordinateC)
         */
        void SetCoordinateParams(const CoordinateDependentParams& params, Scan3dCoordinateSelectorEnums coordinate = Scan3dCoordinateSelector_CoordinateC);

        /**
         * Get coordinate-dependent parameters for all coordinate axes.
         * @return Map of coordinate selector to parameters
         */
        std::map<Scan3dCoordinateSelectorEnums, CoordinateDependentParams> GetAllCoordinateParams() const;

        /**
         * Set coordinate-dependent parameters for all coordinate axes at once.
         * @param params Map of coordinate selector to parameters
         */
        void SetAllCoordinateParams(const std::map<Scan3dCoordinateSelectorEnums, CoordinateDependentParams>& params);

        /** @} */

        /**
         * Convert Scan3D data to StereoCameraParameters struct.
         * For backward compatibility with legacy stereo processing code.
         */
        StereoCameraParameters ToStereoCameraParameters() const;

        /**
         * Populate Scan3D data from StereoCameraParameters struct.
         * For backward compatibility with legacy stereo processing code.
         */
        void FromStereoCameraParameters(const StereoCameraParameters& params);

        friend class Scan3DParametersImpl;

    };
    /**@}*/

    /**@}*/

}
#endif // FLIR_SPINNAKER_SCAN3D_H