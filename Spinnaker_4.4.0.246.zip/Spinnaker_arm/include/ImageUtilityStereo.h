//=============================================================================
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

#ifndef FLIR_SPINNAKER_IMAGE_UTILITY_STEREO_H
#define FLIR_SPINNAKER_IMAGE_UTILITY_STEREO_H

#include "SpinnakerPlatform.h"
#include "SpinnakerDefs.h"
#include "PointCloud.h"
#include "CameraDefs.h"
#include "Image.h"
#include "ImagePtr.h"
#include "CameraPtr.h"
#include "Scan3DParameters.h"

namespace Spinnaker
{
    /**
     *  @defgroup SpinnakerClasses Spinnaker Classes
     */
    /**@{*/

    /**
     *  @defgroup ImageUtilityStereo_h Image Utility Stereo Class
     */
    /**@{*/

    /**
     * @brief Static helper functions for stereo related computations.
     */

    class SPINNAKER_API ImageUtilityStereo
    {
      public:
        /**
         * Returns true if the camera is a stereo camera or false otherwise.
         *
         * @param pCamera The camera
         *
         * @return True if the camera is a stereo camera, or false otherwise
         */
        static bool IsStereoCamera(CameraPtr pCamera);

        /**
         * Post-process the disparity image by filling in holes and reducing noise
         * using the specified disparity processing method. The disparity image is
         * expected to be a Mono16 pixel format image.
         *
         * @param disparityImage The disparity image to fill
         * @param rectifiedImage The rectified image used for filling
         * @param processingMethod The method to use for post processing the disparity image
         * @param scan3dParams The 3D scan parameters containing camera calibration
         *
         * @see Scan3DParameters
         *
         * @return Post-processed disparity image
         */
        static ImagePtr ProcessDisparity(
            const ImagePtr& disparityImage,
            const ImagePtr& rectifiedImage,
            const DisparityProcessingMethod processingMethod,
            const Scan3DParameters& scan3dParams);

        /**
         * @deprecated Use ProcessDisparity with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static ImagePtr ProcessDisparity(
                            const ImagePtr& disparityImage,
                            const ImagePtr& rectifiedImage,
                            const DisparityProcessingMethod processingMethod,
                            const StereoCameraParameters& stereoCameraParameters);)

        /**
         * Post-process the disparity image by filling in holes and reducing noise
         * using the specified disparity processing method. The disparity image is
         * expected to be a Mono16 pixel format image.
         *
         * @param disparityImage The disparity image to fill
         * @param rectifiedImage The rectified image used for filling
         * @param processingMethod The method to use for post processing the disparity image
         * @param scan3dParams The 3D scan parameters containing camera calibration
         *
         * @see Scan3D
         */
        static void ProcessDisparityFromImage(
            ImagePtr& disparityImage,
            const ImagePtr& rectifiedImage,
            const DisparityProcessingMethod processingMethod,
            const Scan3DParameters& scan3dParams);

        /**
         * @deprecated Use ProcessDisparityFromImage with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static void ProcessDisparityFromImage(
                            ImagePtr& disparityImage,
                            const ImagePtr& rectifiedImage,
                            const DisparityProcessingMethod processingMethod,
                            const StereoCameraParameters& stereoCameraParameters);)

        /**
         * Filters speckles from a copy of the input mono disparity image. Note that
         * only Mono16 pixel format image is supported.
         *
         * @param disparityImage The disparity image
         * @param maxSpeckleSize The maximum allowed speckle size
         * @param speckleThreshold The speckle size threshold
         * @param disparityScaleFactor The coordinate scale factor
         * @param invalidDataValue The value assigned to invalid data
         *
         * @return Speckle filtered image
         */
        static ImagePtr FilterSpeckles(
            const ImagePtr& disparityImage,
            const int maxSpeckleSize,
            const float speckleThreshold,
            const float disparityScaleFactor,
            const float invalidDataValue);

        /**
         * Filters speckles in-place on the input mono disparity image. Note that
         * only Mono16 pixel format image is supported.
         *
         * @param disparityImage The disparity image
         * @param maxSpeckleSize The maximum allowed speckle size
         * @param speckleThreshold The speckle size threshold
         * @param disparityScaleFactor The coordinate scale factor
         * @param invalidDataValue The value assigned to invalid data
         */
        static void FilterSpecklesFromImage(
            ImagePtr& disparityImage,
            const int maxSpeckleSize,
            const float speckleThreshold,
            const float disparityScaleFactor,
            const float invalidDataValue);

        /**
         * Creates an 8-bit gradient magnitude image from rectified image. The gradient
         * magnitude is computed by converting rectified image to a grayscale image and applying
         * Sobel filters in the X and Y direction.
         *
         * @param rectifiedImage Rectified image
         *
         * @return Gradient magnitude image
         */
        static ImagePtr CreateGradientImage(const ImagePtr& rectifiedImage);

        /**
         * Creates an 8-bit gradient magnitude image from rectified image. The gradient
         * magnitude is computed by converting rectified image to a grayscale image and applying
         * Sobel filters in the X and Y direction. Resulting gradient data is stored in the
         * provided gradientImage object.
         *
         * @param rectifiedImage Rectified image
         * @param gradientImage The image where the gradient data will be stored
         */
        static void CreateGradientImage(const ImagePtr& rectifiedImage, ImagePtr& gradientImage);

        /**
         * Performs edge-aware interpolation on the input disparity image to fill in
         * invalid pixels, using information from nearby valid pixels and edges. Note that
         * only Mono16 pixel format disparity image is supported.
         *
         * @see CreateGradientImage
         *
         * @param disparityImage The disparity image (Mono16)
         * @param invalidDataValue The value assigned to invalid data
         * @param gradientImage The gradient magnitude image (Mono8)
         * @param edgeThreshold The threshold for edge detection
         * @param maxDistance The maximum distance to search for valid pixels
         *
         * @return Edge-aware interpolated image
         */
        static ImagePtr EdgeInterpolation(
            const ImagePtr& disparityImage,
            const float invalidDataValue,
            const ImagePtr& gradientImage,
            const float edgeThreshold,
            const int maxDistance);

        /**
         * Performs edge-aware interpolation in-place on the input disparity image to
         * fill in invalid pixels, using information from nearby valid pixels and edges. Note
         * that only Mono16 pixel format disparity image is supported.
         *
         * @see CreateGradientImage
         *
         * @param disparityImage The disparity image (Mono16)
         * @param invalidDataValue The value assigned to invalid data
         * @param gradientImage The gradient magnitude image (Mono8)
         * @param edgeThreshold The threshold for edge detection
         * @param maxDistance The maximum distance to search for valid pixels
         */
        static void EdgeInterpolationFromImage(
            ImagePtr& disparityImage,
            const float invalidDataValue,
            const ImagePtr& gradientImage,
            const float edgeThreshold,
            const int maxDistance);

        /**
         * Applies a joint bilateral filter on the input disparity image using the
         * corresponding rectified image as a guide. This edge-preserving filter smooths
         * the disparity image while maintaining sharp edges aligned with the guide image.
         * The filter uses both spatial and color information to determine the influence of
         * neighboring pixels. Only Mono16 pixel format disparity images are supported.
         *
         * @param disparityImage The disparity image to be filtered (Mono16)
         * @param rectifiedImage The rectified image used as the guide for edge preservation
         * @param sigmaSpatial The spatial standard deviation for the filter kernel
         * @param sigmaColor The color standard deviation for the filter kernel
         * @param filterDiameter The diameter of the filter kernel
         *
         * @return Joint bilateral filtered image
         */
        static ImagePtr JointBilateral(
            const ImagePtr& disparityImage,
            const ImagePtr& rectifiedImage,
            const float sigmaSpatial,
            const float sigmaColor,
            const int filterDiameter);

        /**
         * Applies a joint bilateral filter in-place on the input disparity image using
         * the corresponding rectified image as a guide. This edge-preserving filter smooths
         * the disparity image while maintaining sharp edges aligned with the guide image.
         * The filter uses both spatial and color information to determine the influence of
         * neighboring pixels. Only Mono16 pixel format disparity images are supported.
         *
         * @param disparityImage The disparity image to be filtered (Mono16)
         * @param rectifiedImage The rectified image used as the guide for edge preservation
         * @param sigmaSpatial The spatial standard deviation for the filter kernel
         * @param sigmaColor The color standard deviation for the filter kernel
         * @param filterDiameter The diameter of the filter kernel
         */
        static void JointBilateralFromImage(
            ImagePtr& disparityImage,
            const ImagePtr& rectifiedImage,
            const float sigmaSpatial,
            const float sigmaColor,
            const int filterDiameter);

        /**
         * Applies a fast, edge-preserving filter on the input disparity image using the
         * domain transform normalized convolution technique. The filter uses a joint image to
         * guide smoothing, preserving edges present in the guide while smoothing the target
         * image. Note that only Mono16 pixel format disparity image is supported.
         *
         * @param disparityImage The disparity image (Mono16)
         * @param rectifiedImage The rectified image
         * @param sigmaSpatial The spatial standard deviation for the filter
         * @param sigmaColor The color standard deviation for the filter
         * @param numIterations The number of iterations to perform (default is 3)
         *
         * @return Filtered disparity image
         */
        static ImagePtr DomainTransform(
            const ImagePtr& disparityImage,
            const ImagePtr& rectifiedImage,
            const float sigmaSpatial,
            const float sigmaColor,
            const int numIterations = 3);

        /**
         * Applies a fast, edge-preserving filter in-place on the input disparity image using
         * the domain transform normalized convolution technique. The filter uses a joint image
         * to guide smoothing, preserving edges present in the guide while smoothing the target
         * image. Note that only Mono16 pixel format disparity image is supported.
         *
         * @param disparityImage The disparity image (Mono16)
         * @param rectifiedImage The rectified image
         * @param sigmaSpatial The spatial standard deviation for the filter
         * @param sigmaColor The color standard deviation for the filter
         * @param numIterations The number of iterations to perform (default is 3)
         */
        static void DomainTransformFromImage(
            ImagePtr& disparityImage,
            const ImagePtr& rectifiedImage,
            const float sigmaSpatial,
            const float sigmaColor,
            const int numIterations = 3);

        /**
         * Computes 3D point from disparity value.
         *
         * @param disparity The disparity value
         * @param scan3dParams The 3D scan parameters containing camera calibration
         * @param stereo3DPoint The computed 3D point
         *
         * @see Scan3D
         *
         * @return True if the function finished successfully, or false otherwise
         */
        static bool Compute3DPointFromPixel(
            const uint16_t disparity,
            const Scan3DParameters& scan3dParams,
            Stereo3DPoint& stereo3DPoint);

        /**
         * @deprecated Use Compute3DPointFromPixel with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static bool Compute3DPointFromPixel(
                            const uint16_t disparity,
                            const StereoCameraParameters& stereoCameraParameters,
                            Stereo3DPoint& stereo3DPoint);)

        /**
         * @brief Computes 3D point cloud from stereo images (range + intensity).
         *
         * This function transforms range and intensity data from a stereo camera pair
         * into a 3D point cloud using camera calibration parameters. Each point contains
         * X, Y, Z coordinates in world space plus RGB color information from the intensity
         * image.
         *
         * The actual unit of measurement for the point cloud coordinates is determined by
         * the Scan3DParameters camera calibration parameters.
         *
         * **Requirements:**
         * - rangeImage must be Mono16/Coord3D format containing disparity or range values
         * - intensityImage provides RGB/intensity data for each point
         * - Images must be from synchronized stereo pair with same dimensions
         * - Scan3DParameterss must contain valid camera calibration
         *
         * **Point Cloud Computation:**
         * For each pixel (u, v) with disparity value d:
         * - Z = (baseline * focalLength) / (d * coordinateScale + coordinateOffset)
         * - X = (u - principalPointU) * Z / focalLength
         * - Y = (v - principalPointV) * Z / focalLength
         *
         * @param rangeImage The range image (Mono16/Coord3D format) from stereo matching
         * @param intensityImage The intensity image providing color/intensity data (Typically a rectified image)
         * @param pointCloudParameters Parameters controlling ROI, decimation, and filtering
         * @param scan3dParams Camera calibration parameters (baseline, focal length, etc.)
         *
         * @return PointCloud object containing 3D points with XYZ coordinates and RGB colors
         *
         * @code{.cpp}
         * // Example usage
         * ImagePtr disparityImg = imageList.GetByPayloadType(
         *     SPINNAKER_IMAGE_PAYLOAD_TYPE_DISPARITY_SENSOR1);
         * ImagePtr rectifiedImg = imageList.GetByPayloadType(
         *     SPINNAKER_IMAGE_PAYLOAD_TYPE_RECTIFIED_SENSOR1);
         *
         * Scan3D scan3dParams;
         * scan3dParams.SetScan3DParameters(pCamera->GetNodeMap());
         *
         * PointCloudParameters pcParams;
         * pcParams.decimationFactor = 1;  // No decimation
         * pcParams.ROIImageLeft = 0;
         * pcParams.ROIImageTop = 0;
         * pcParams.ROIImageRight = disparityImg->GetWidth();
         * pcParams.ROIImageBottom = disparityImg->GetHeight();
         *
         * PointCloud pointCloud = ImageUtilityStereo::ComputePointCloud(
         *     disparityImg, rectifiedImg, pcParams, scan3dParams);
         *
         * pointCloud.SavePointCloudAsPly("output.ply");
         * @endcode
         *
         * @see Scan3D for camera calibration parameters
         * @see PointCloudParameters for computation settings
         * @see PointCloud for output format and saving options
         * @see ProcessDisparity() for disparity preprocessing
         *
         * @note For best results, preprocess disparity images using ProcessDisparity()
         *       to fill holes and reduce noise before computing the point cloud.
         */
        static PointCloud ComputePointCloud(
            const ImagePtr& rangeImage,
            const ImagePtr& intensityImage,
            const PointCloudParameters& pointCloudParameters,
            const Scan3DParameters& scan3dParams);

        /**
         * @deprecated Use ComputePointCloud with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static PointCloud ComputePointCloud(
                            const ImagePtr& rangeImage,
                            const ImagePtr& intensityImage,
                            const PointCloudParameters& pointCloudParameters,
                            const StereoCameraParameters& stereoCameraParameters);)

        /**
         * Computes 3D point cloud from a stereo pair consisting of a Coord3D range and
         * intensity image using a stereo matching algorithm.
         *
         * @param rangeImage The Coord3D range/disparity image from a stereo pair
         * @param intensityImage The intensity image from a stereo pair consisting (Typically
         *                       a rectified image)
         * @param pointCloudParameters The parameters for computing the point cloud
         * @param scan3dParams The 3D scan parameters containing camera calibration
         * @param pointCloud The computed point cloud will be stored in this object
         *
         * @see Scan3D
         * @see PointCloudParameters
         */
        static void ComputePointCloud(
            const ImagePtr& rangeImage,
            const ImagePtr& intensityImage,
            const PointCloudParameters& pointCloudParameters,
            const Scan3DParameters& scan3dParams,
            PointCloud& pointCloud);

        /**
         * @deprecated Use ComputePointCloud with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static void ComputePointCloud(
                            const ImagePtr& rangeImage,
                            const ImagePtr& intensityImage,
                            const PointCloudParameters& pointCloudParameters,
                            const StereoCameraParameters& stereoCameraParameters,
                            PointCloud& pointCloud);)

        /**
         * Computes the distance of a point to the camera world coordinates origin,
         * from the Coord3D range/disparity image.
         *
         * Supports multiple image payload types and pixel formats:
         * - DISPARITY_SENSOR1: Mono16 disparity images
         * - RANGE_SENSOR1/RANGE_SENSOR2: Coord3D formats (C16, C32f, ABC16, ABC32f)
         *
         * @param rangeImage The Coord3D range/disparity image
         * @param scan3dParams The 3D scan parameters containing camera calibration
         * @param imagePixel The pixel in the image
         * @param distance The distance of the point to the camera world coordinates origin
         *
         * @see Scan3D
         *
         * @return True if the function finished successfully, or false otherwise.
         */
        static bool ComputeDistanceToPoint(
            const ImagePtr& rangeImage,
            const Scan3DParameters& scan3dParams,
            const ImagePixel& imagePixel,
            float& distance);

        /**
         * @deprecated Use ComputeDistanceToPoint with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static bool ComputeDistanceToPoint(
                            const ImagePtr& rangeImage,
                            const StereoCameraParameters& stereoParam,
                            const ImagePixel& imagePixel,
                            float& distance);)

        /**
         * Computes the distance between two points in the Coord3D range/disparity image.
         *
         * Supports multiple image payload types and pixel formats:
         * - DISPARITY_SENSOR1: Mono16 disparity images
         * - RANGE_SENSOR1/RANGE_SENSOR2: Coord3D formats (C16, C32f, ABC16, ABC32f)
         *
         * @param rangeImage The Coord3D range/disparity image
         * @param scan3dParams The 3D scan parameters containing camera calibration
         * @param imagePixel1 The first pixel in the image
         * @param imagePixel2 The second pixel in the image
         * @param distance The distance between the two points
         *
         * @see Scan3D
         *
         * @return True if the function finished successfully, or false otherwise
         */
        static bool ComputeDistanceBetweenPoints(
            const ImagePtr& rangeImage,
            const Scan3DParameters& scan3dParams,
            const ImagePixel& imagePixel1,
            const ImagePixel& imagePixel2,
            float& distance);

        /**
         * @deprecated Use ComputeDistanceBetweenPoints with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static bool ComputeDistanceBetweenPoints(
                            const ImagePtr& rangeImage,
                            const StereoCameraParameters& stereoParam,
                            const ImagePixel& imagePixel1,
                            const ImagePixel& ImagePixel2,
                            float& distance);)

        /**
         * Computes a depth image.
         *
         * The source image is required to carry Coord3D disparity or range information.
         * Given disparity data, a depth image reinterprets disparity data by mapping
         * the disparity for each pixel to a depth (z) value based on the image focal
         * length and baseline. The depth data is transformed into world coodinates
         * using the provided camera calibration from Scan3DParams and stored in
         * Coord3D_C32f container.
         *
         * The actual unit of measurement for the depth image is determined by
         * the Scan3DParameters camera calibration parameters.
         *
         * @param rangeImage The source image from which to create the depth values
         * @param scan3dParams The 3D scan parameters containing camera calibration
         * @param minDepthVal The actual minimum depth in the image
         * @param maxDepthVal The actual maximum depth in the image
         *
         * @see Scan3D
         *
         * @return The depth image
         */
        static ImagePtr CreateDepthImage(
            const ImagePtr& rangeImage,
            const Scan3DParameters& scan3dParams,
            float& minDepthVal,
            float& maxDepthVal);

        /**
         * @deprecated Use CreateDepthImage with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static ImagePtr CreateDepthImage(
                            const ImagePtr& rangeImage,
                            const StereoCameraParameters& stereoCameraParameters,
                            const uint16_t invalidDepthVal,
                            float& minDepthVal,
                            float& maxDepthVal);)

        /**
         * Computes a depth image.
         *
         * The source image is required to carry Coord3D disparity or range information.
         * Given disparity data, a depth image reinterprets disparity data by mapping
         * the disparity for each pixel to a depth (z) value based on the image focal
         * length and baseline. The depth data is transformed into world coodinates
         * using the provided camera calibration from Scan3DParams and stored in
         * Coord3D_C32f container.
         *
         * The destination is required to be initialized with the appropriate Coord3D_C32f
         * pixel format, and have the same width, height, x offset, and y offset
         * as the source image.
         *
         * The actual unit of measurement for the depth image is determined by
         * the Scan3DParameters camera calibration parameters.
         *
         * @param rangeImage The source image from which to create the depth values
         * @param scan3dParams The 3D scan parameters containing camera calibration
         * @param depthImage The destination image in which to store the created depth values
         * @param minDepthVal The actual minimum depth in the image
         * @param maxDepthVal The actual maximum depth in the image
         *
         * @see Scan3D
         */
        static void CreateDepthImage(
            const ImagePtr& rangeImage,
            const Scan3DParameters& scan3dParams,
            ImagePtr& depthImage,
            float& minDepthVal,
            float& maxDepthVal);

        /**
         * @deprecated Use CreateDepthImage with Scan3DParameters instead
         */
        DEPRECATED_FUNC("Use Scan3DParameters instead of StereoCameraParameters",
                        static void CreateDepthImage(
                            const ImagePtr& rangeImage,
                            const StereoCameraParameters& stereoCameraParameters,
                            const uint16_t invalidDepthVal,
                            ImagePtr& depthImage,
                            float& minDepthVal,
                            float& maxDepthVal);)

        /**
         * @deprecated Use Scan3DParameters::GetAxisMax() and Scan3DParameters::GetDistanceUnit() instead.
         */
        static uint16_t maxDepthThresholdInMm;

        /**
         * @deprecated Use Scan3DParameters::GetAxisMax() and Scan3DParameters::GetDistanceUnit() instead.
         */
        static uint16_t maxDepthThresholdInMeter;
    };

    /**@}*/

    /**@}*/
} // namespace Spinnaker

#endif // FLIR_SPINNAKER_IMAGE_UTILITY_STEREO_H