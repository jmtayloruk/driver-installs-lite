//=============================================================================  
// Copyright (c) 2026 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.  
//  
// This software is the confidential and proprietary information of FLIR  
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You  
// shall not disclose such Confidential Information and shall use it only in  
// accordance with the terms of the license agreement you entered into  
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).  
//  
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE  
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE  
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR  
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES  
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING  
// THIS SOFTWARE OR ITS DERIVATIVES.  
//  =============================================================================

# README <!-- omit in toc -->

# TABLE OF CONTENTS <!-- omit in toc -->

- [1. DEPENDENCIES](#1-dependencies)
- [1.1. DEPENDENCY INSTALLATION](#11-dependency-installation)
- [2. SPINNAKER INSTALLATION](#2-spinnaker-installation)
  - [2.1. REMOVING QUARANTINE ATTRIBUTES](#21-removing-quarantine-attributes)
- [3. GIGE CAMERA SETUP](#3-gige-camera-setup)
  - [3.1. ENABLE JUMBO PACKET](#31-enable-jumbo-packet)
  - [3.2. NETWORKING BEST PRACTICES](#32-networking-best-practices)
  - [3.3. ADJUST TRANSMIT QUEUE LENGTH (SEND/RECEIVE BUFFERS)](#33-adjust-transmit-queue-length-sendreceive-buffers)
  - [3.4. NETWORK BUFFER TUNING WITH GEV_NETTWEAK](#34-network-buffer-tuning-with-gev_nettweak)
- [4. RUNNING EXAMPLES](#4-running-examples)
- [5. GENICAM GENTL PRODUCER SETUP](#5-genicam-gentl-producer-setup)
  - [5.1. GENTL LOGGING](#51-gentl-logging)
- [6. SPINNAKER REMOVAL](#6-spinnaker-removal)
- [7. TELEDYNE-MV SPINNAKER EXAMPLES](#7-teledyne-mv-spinnaker-examples)


===============================================================================
## 1. DEPENDENCIES  
===============================================================================

To build and/or run Spinnaker applications on macOS you will need to install 
some prerequisite libraries.  
Below is a list of libraries and tools that Spinnaker depends on, organized by 
the respective tools used to fetch Spinnaker dependencies.

Required:
1) Homebrew

       a. pkg-config
       c. libomp
       d. libusb
       e. ffmpeg@6

Required:  
macOS Sonoma (14) or above.

-------------------------------------------------------------------------------
1.1. DEPENDENCY INSTALLATION
-------------------------------------------------------------------------------

This section contains instructions for getting your macOS machine
ready to compile and use the Spinnaker library.

1) Homebrew

Many of the listed dependencies can be installed via a package manager named
Homebrew.  
Homebrew does not come by default on macOS so run the following command in 
Terminal to install Homebrew onto your system:

    user$:  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

Enter your password if asked.

Wait until you see "Next Steps". At this point Homebrew should be installed on to your system.

A list of packages and other documentation relating to Homebrew can be found
at https://brew.sh/.  
Below is a list of dependencies for Spinnaker that we will need to install via
Homebrew.

- pkg-config
- libomp
- libusb
- FFMPEG@6
    - libswscale
    - libswresample
    - libavcodec
    - libavformat

Run the following command to install all of the dependencies using:

    brew install pkg-config libomp libusb ffmpeg@6

Using a newer version of FFMPEG will result in failure.

===============================================================================
## 2. SPINNAKER INSTALLATION
===============================================================================

To install this package, simply double-click on the supplied Spinnaker dmg
file. This installer will walk you through the setup and place individual packages
in their appropriate locations. This generates the following directory structure:

    /Applications/Spinnaker/lib
    /Applications/Spinnaker/include
    /Applications/Spinnaker/examples
    /Applications/Spinnaker/PySpin

Spinnaker libraries are copied to /usr/local/lib on installation.

Spinnaker headers are copied to /usr/local/include for system-wide reference,
but a copy of the headers has been left in /Applications/Spinnaker/include
for reference.

-------------------------------------------------------------------------------
### 2.1. REMOVING QUARANTINE ATTRIBUTES
-------------------------------------------------------------------------------

After installation, you may encounter security warnings when running Spinnaker 
applications with errors like:

    "libGenApi_clang140_v3_0.dylib" cannot be opened because the developer 
    cannot be verified. macOS cannot verify that this app is free from malware.

This happens because macOS applies a "quarantine" attribute to files that are 
downloaded or installed from external sources as a security measure. To resolve 
this issue, you need to remove the quarantine attribute from the Spinnaker 
libraries.

Run the following command to remove the quarantine attribute for all Spinnaker 
libraries:

    sudo xattr -r -d com.apple.quarantine /usr/local/lib/

This command will:
- Remove the quarantine attribute (-d com.apple.quarantine)
- Apply recursively to all subdirectories (-r) 
- Target the library installation directory (/usr/local/lib/)

You may be prompted for your administrator password. After running this command,
you should be able to run Spinnaker applications without security warnings.

Note: This is safe to do for trusted software like Spinnaker. The quarantine 
attribute is simply macOS being cautious about externally installed libraries.

===============================================================================
## 3. GIGE CAMERA SETUP
===============================================================================

-------------------------------------------------------------------------------
### 3.1. ENABLE JUMBO PACKET
-------------------------------------------------------------------------------

Jumbo Packet is strongly recommended to be enabled for the network adapter and
the camera, in order to greatly improve streaming results.

Run ifconfig and find the network adapter that the cameras are connected to
(eg. en13):

    $ ifconfig

It might be necessary to disconnect the camera and run ifconfig again to find
the output difference, in order to find the network adapter name.

To TEMPORARILY enable Jumbo Packet for a specific network adapter, e.g. en13

    $ networksetup -setMTU en13 9000

Note: Depending on your network adapter, the valid MTU ranges may differ.

Refer to the following article provided by Apple for additional information
on how to PERMANENTLY enable Jumbo Packet for a specific network adapter:
https://support.apple.com/en-ca/HT2532

-------------------------------------------------------------------------------
### 3.2. NETWORKING BEST PRACTICES
-------------------------------------------------------------------------------

Using a subnet mask of `255.255.255.0` (or /24 in CIDR). 
This is a common practice in many network setups and is
preferred for the following reasons:

1) Network Size: Subnet masks of 255.255.255.0 allows for 256 possible IP 
   addresses.  
   This is suitable for small to medium size networks where you need to
   accommodate less than 256 devices.

2) IP Address Allocation: Plan your IP address allocation carefully to ensure
   efficient use of the available addresses within the subnet.

3) Performance: Smaller subnets can reduce broadcast traffic and improve network
   performance, since we don't need a lot of space for 256 cameras we might as 
   well take advantage of this.

It is also a good practice to avoid LLA (169.254.x.x) as the
Network Interface Cards statically assigned IP.  
In short we don't want to do this because it causes address conflicts,
incompatibilities, and unpredictable behaviours.  
For an in depth explanation look at the following link under subsection
`Guidelines for Configuring Multi-NIC Systems`:   
<https://www.ni.com/en/support/documentation/supplemental/11/best-practices-for-using-multiple-network-interfaces--nics--with.html>

-------------------------------------------------------------------------------
### 3.3. ADJUST TRANSMIT QUEUE LENGTH (SEND/RECEIVE BUFFERS)
-------------------------------------------------------------------------------

The link-layer queue knobs (`net.link.generic.system.sndq_maxlen` /
`rcvq_maxlen`) and the UDP socket buffer knobs (`net.inet.udp.recvspace` /
`kern.ipc.maxsockbuf`) are all tuned automatically by the `gev_nettweak`
utility described in section [3.4](#34-network-buffer-tuning-with-gev_nettweak).
Running `gev_nettweak` is the recommended approach.

If you need to check or set these values manually:

    # Check current values
    sysctl net.link.generic.system.sndq_maxlen
    sysctl net.link.generic.system.rcvq_maxlen

    # Set queue lengths (example: 2048)
    sudo sysctl -w net.link.generic.system.rcvq_maxlen=2048
    sudo sysctl -w net.link.generic.system.sndq_maxlen=2048

Note: These changes reset on reboot. To persist them, add the key=value pairs
to `/etc/sysctl.conf` (create the file if it does not exist), or follow the
launchd approach below.

To permanently set this, a launchd item that runs at startup can be created.  
See https://www.launchd.info/ for more info.

Overview of steps:
1. Create property list XML file at `/Library/LaunchDaemons` which specifies the 
   shell script to run
2. Permanently load the launchd item to run at startup by running the following 
   command:
   
       sudo launchctl load -w /Library/LaunchDaemons/com.[example_name].plist

Notable potential issues:
- If launchd item runs a shell script, the script may need to be placed 
  somewhere that's accessible when run as root user (which is the default user
  in a launchd item), e.g. `/home/`
- May need to give full disk access to `bash/zsh` for launchd item to be able to 
  run script, which can be configured at 
  `System Settings > Privacy and Security > Full Disk Access`

-------------------------------------------------------------------------------
### 3.4. NETWORK BUFFER TUNING WITH GEV_NETTWEAK
-------------------------------------------------------------------------------

`gev_nettweak` is a utility script installed to `/Applications/Spinnaker/Utilities/`
that automates the macOS network tuning steps required for reliable GigE camera
streaming. It performs the following in a single step:

- **MTU (Jumbo Packet)**: Probes the NIC for the highest supported MTU starting
  at 9216 bytes, stepping down until one succeeds (minimum 1500). This is the
  macOS equivalent of enabling Jumbo Packet via `networksetup`.
- **Socket buffer ceiling** (`kern.ipc.maxsockbuf`): Sets the system-wide socket
  buffer ceiling to two full maximum-resolution images, which is required for the
  `recvspace` increase to take effect. This is the macOS equivalent of Linux
  `net.core.rmem_max`.
- **UDP receive buffer** (`net.inet.udp.recvspace`): Sets the default socket
  receive buffer to one full maximum-resolution image (2448×2048 bytes). This is
  the macOS equivalent of Linux `net.core.rmem_default`.
- **Link-layer receive queue length** (`net.link.generic.system.rcvq_maxlen`):
  Increases the system receive queue limit used by the network stack to better
  accommodate sustained GigE Vision traffic bursts.
- **Link-layer send queue length** (`net.link.generic.system.sndq_maxlen`):
  Increases the system send queue limit used by the network stack alongside the
  receive-side tuning performed by the utility.

Note: `ethtool` NIC ring buffer tuning is not available on macOS. Jumbo frame
support beyond what `gev_nettweak` sets must be configured via
`System Settings > Network > <interface> > Details > Hardware`.

**Usage**

Run the script with `sudo` and supply the name of the network interface your
camera is connected to (use `ifconfig` to find the interface name):

    sudo /Applications/Spinnaker/Utilities/gev_nettweak <netif_name>

Example for interface `en13`:

    sudo /Applications/Spinnaker/Utilities/gev_nettweak en13

**Making changes persistent across reboots**

The sysctl changes applied by `gev_nettweak` are temporary and reset on reboot.
To persist them, add the following lines to `/etc/sysctl.conf` (create the file
if it does not exist):

    kern.ipc.maxsockbuf=10027008
	net.inet.udp.recvspace=5013504
    net.link.generic.system.rcvq_maxlen=4096
    net.link.generic.system.sndq_maxlen=4096

The MTU setting must still be re-applied after each reboot via `gev_nettweak` or
by permanently enabling jumbo frames through System Settings as described in
section [3.1](#31-enable-jumbo-packet).

===============================================================================
## 4. RUNNING EXAMPLES
===============================================================================

After installing the included Spinnaker.pkg file, the Spinnaker library can
be read by default from any terminal session.  
Simply run the desired example from any directory.

Precompiled C++ examples are placed at `/Applications/Spinnaker/bin`.  
These can be run from anywhere, but they require write permission to the working
directory.  
You may have to run these examples as sudo if the current working directory 
requires elevated permission to write files.

The source code for examples is located at `/Applications/Spinnaker/src/`.

Although examples are placed in `/Applications/Spinnaker/examples` they have to
be run outside of the directory due to permission issues.

===============================================================================
## 5. GENICAM GENTL PRODUCER SETUP
===============================================================================

In order to use the Spinnaker GenTL producer with applications that support 
consuming the Spinnaker GenTL producer, the location of Spinnaker_GenTL.cti must
be added to the `GENICAM_GENTL64_PATH` environment variable.

The Spinnaker installer will run a configuration script automatically after
install that adds to the `GENICAM_GENTL64_PATH` environment variable by copying
`/usr/local/lib/spinnaker-gentl/zprofile.spinnakergentl` text to `~/.zprofile`.  
The environment variable will be configured for any new zsh terminal session.

The configure_gentl_path.sh script can be found in the Spinnaker Utilities
folder and can be run with '-u' to remove the zprofile.spinnakergentl text from
`~/.zprofile`.  
Note this is done automatically through the uninstall_spinnaker.sh script.

The Spinnaker GenTL producer can be found in `/usr/local/lib/spinnaker-gentl`
along with the zsh profile configuration file and GenTL logging configuration 
file.

-------------------------------------------------------------------------------
### 5.1. GENTL LOGGING
-------------------------------------------------------------------------------

To enable Spinnaker GenTL logging, copy the logging configuration file
`log4cpp.gentl.property` from `Applications/Spinnaker/lib/spinnaker-gentl` or
`/usr/local/lib/spinnaker-gentl` to the location that the consumer application
executes from.  
The logging configuration file can be modified for specific levels of logging.

===============================================================================
## 6. SPINNAKER REMOVAL
===============================================================================

To uninstall Spinnaker, run the supplied `uninstall_spinnaker.sh` script.  
This script is *not* installed in `/Applications/Spinnaker` with everything else
but is a standalone script included in the Spinnaker dmg file.  
This uninstall script will remove all installed Spinnaker files and will
remove Spinnaker from your Mac's list of installed applications.

===============================================================================
## 7. TELEDYNE-MV SPINNAKER EXAMPLES
===============================================================================
Please visit our Github repository for examples you can refer to at:  
<https://github.com/Teledyne-MV/Spinnaker-Examples>
