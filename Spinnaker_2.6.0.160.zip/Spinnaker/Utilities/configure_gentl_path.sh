#!/bin/bash
# FLIR provides a bash profile file in /usr/local/lib/flir-gentl/ that adds the FLIR GenTL 
# producer to the GNEICAM_GENTL64_PATH environment variable.
# This script appends or removes the text to or from the current users bash_profile.
# To append, provide no arguments, to remove provide "-u" ( ex. 'configure_gentl_path.sh -u').

# Define common variables
BASH_PROFILE=~/.bash_profile
CTI_PATH=/usr/local/lib/flir-gentl
FLIR_BASH_PROFILE=$CTI_PATH/bash_profile.flirgentl
BASH_PROFILE_OWNER="Unknown"

# Helper function to exit early if the FLIR bash profile is not found
# and let the user know if they will be asked for the sudo password
check_for_config_file_and_permission_level(){
    if ! [ -f $FLIR_BASH_PROFILE ]; then
        echo "Error: File not found: ${FLIR_BASH_PROFILE}"
        exit 1
    fi

    prompt=$(sudo -nv 2>&1)
    if ! [ $? -eq 0 ]; then
        echo "Please enter the sudo password for permission to write to ${BASH_PROFILE}"
    fi
}

# Pass the bash profile owner to the function.
print_error_msg(){
    echo "Error: Failed to configure FLIR GenTL producer in ${BASH_PROFILE}."
    if ( [ $BASH_PROFILE_OWNER = "root" ] && ! [ $(id -un) = $BASH_PROFILE_OWNER ] ); then
        echo "    The bash profile file owner is root, try running the script with sudo."
    fi
    exit 1
}

if ! ( [ "$1" = "-u" ] || [ "$1" = "-U" ] ); then
    # Add the FLIR bash profile if needed.
    MY_YESNO_PROMPT='[Y/n] $ '
    echo "Would you like to add the FLIR GenTL producer path to the GENICAM_GENTL64_PATH environment variable?"
    echo "This is recommended if you wish to use the FLIR GenTL producer."
    printf "$MY_YESNO_PROMPT"
    read confirm
    if ! ( [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ] )
    then
        exit 0
    fi

    if ! [ -f $BASH_PROFILE ]; then
        touch $BASH_PROFILE
    elif grep -q ${CTI_PATH} "${BASH_PROFILE}"; then
        echo "The FLIR GenTL producer path was found in ${BASH_PROFILE}. No action required."
        echo "To remove the path, run the script with -u"
        exit 0
    fi

    check_for_config_file_and_permission_level

    BASH_PROFILE_OWNER=$(ls -ld $BASH_PROFILE | awk '{print $3}')

    # Ensure a new line before adding FLIR bash profile
    if ! [ "$(tail -1 ${BASH_PROFILE})" = "" ]; then
        if ! sudo echo ''  >> $BASH_PROFILE; then
            print_error_msg
        fi
    fi

    if ! sudo cat $FLIR_BASH_PROFILE >> $BASH_PROFILE; then
        print_error_msg
    fi

    echo "Successfully added FLIR GenTL producer configuration to ${BASH_PROFILE}."
    echo "To remove the configuration, run the script with -u"
    echo "Changes will apply to any new terminal session."
else
    echo "Proceeding with removal of FLIR GenTL producer bash configuration..." 

    # Remove the FLIR bash profile if needed.
    if ! [ -f $BASH_PROFILE ] || ! grep -q ${CTI_PATH} "${BASH_PROFILE}"; then
        echo "The FLIR GenTL producer path was not found in ${BASH_PROFILE}. No action performed."
        exit 0
    fi

    check_for_config_file_and_permission_level

    TEMP_BASH_PROFILE=/tmp/temp_bash_profile
    BASH_PROFILE_OWNER=$(ls -ld $BASH_PROFILE | awk '{print $3}')

    if [ -f $TEMP_BASH_PROFILE ]; then
        rm $TEMP_BASH_PROFILE
    fi

    sudo grep -Fxvf $FLIR_BASH_PROFILE $BASH_PROFILE > $TEMP_BASH_PROFILE

    # Ensure we don't change the owner of bash profile
    if ! chown $BASH_PROFILE_OWNER $TEMP_BASH_PROFILE  || ! mv $TEMP_BASH_PROFILE $BASH_PROFILE; then
        sudo rm $TEMP_BASH_PROFILE
        print_error_msg
    fi

    echo "Successfully removed FLIR GenTL producer configuration from ${BASH_PROFILE}."
    echo "To add configuration back, run the script without any parameters."
    echo "Changes will apply to any new terminal session."
fi