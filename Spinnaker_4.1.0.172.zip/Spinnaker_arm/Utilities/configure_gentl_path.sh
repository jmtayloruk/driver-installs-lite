#!/bin/bash
# Spinnaker provides a zsh profile file in /usr/local/lib/spinnaker-gentl/ that adds the Spinnaker GenTL 
# producer to the GNEICAM_GENTL64_PATH environment variable.
# This script appends or removes the text to or from the current users zprofile.
# To append, provide no arguments, to remove provide "-u" ( ex. 'configure_gentl_path.sh -u').

# Define common variables
ZPROFILE=~/.zprofile
CTI_PATH=/usr/local/lib/spinnaker-gentl
SPINNAKER_ZPROFILE=$CTI_PATH/zprofile.spinnakergentl
ZPROFILE_OWNER="Unknown"

# Helper function to exit early if the Spinnaker zprofile is not found
# and let the user know if they will be asked for the sudo password
check_for_config_file_and_permission_level(){
    if ! [ -f $SPINNAKER_ZPROFILE ]; then
        echo "Error: File not found: ${SPINNAKER_ZPROFILE}"
        exit 1
    fi

    prompt=$(sudo -nv 2>&1)
    if ! [ $? -eq 0 ]; then
        echo "Please enter the sudo password for permission to write to ${ZPROFILE}"
    fi
}

# Pass the zprofile owner to the function.
print_error_msg(){
    echo "Error: Failed to configure Spinnaker GenTL producer in ${ZPROFILE}."
    if ( [ $ZPROFILE_OWNER = "root" ] && ! [ $(id -un) = $ZPROFILE_OWNER ] ); then
        echo "    The zprofile file owner is root, try running the script with sudo."
    fi
    exit 1
}

if ! ( [ "$1" = "-u" ] || [ "$1" = "-U" ] ); then
    # Add the Spinnaker zsh profile if needed.
    MY_YESNO_PROMPT='[Y/n] $ '
    echo "Would you like to add the Spinnaker GenTL producer path to the GENICAM_GENTL64_PATH environment variable?"
    echo "This is recommended if you wish to use the Spinnaker GenTL producer."
    printf "$MY_YESNO_PROMPT"
    read confirm
    if ! ( [ "$confirm" = "y" ] || [ "$confirm" = "Y" ] || [ "$confirm" = "yes" ] || [ "$confirm" = "Yes" ] || [ "$confirm" = "" ] )
    then
        exit 0
    fi

    if ! [ -f $ZPROFILE ]; then
        touch $ZPROFILE
    elif grep -q ${CTI_PATH} "${ZPROFILE}"; then
        echo "The Spinnaker GenTL producer path was found in ${ZPROFILE}. No action required."
        echo "To remove the path, run the script with -u"
        exit 0
    fi

    check_for_config_file_and_permission_level

    ZPROFILE_OWNER=$(ls -ld $ZPROFILE | awk '{print $3}')

    # Ensure a new line before adding Spinnaker zsh profile
    if ! [ "$(tail -1 ${ZPROFILE})" = "" ]; then
        if ! sudo echo ''  >> $ZPROFILE; then
            print_error_msg
        fi
    fi

    if ! sudo cat $SPINNAKER_ZPROFILE >> $ZPROFILE; then
        print_error_msg
    fi

    echo "Successfully added Spinnaker GenTL producer configuration to ${ZPROFILE}."
    echo "To remove the configuration, run the script with -u"
    echo "Changes will apply to any new terminal session."
else
    echo "Proceeding with removal of Spinnaker GenTL producer zsh configuration..." 

    # Remove the Spinnaker zsh profile if needed.
    if ! [ -f $ZPROFILE ] || ! grep -q ${CTI_PATH} "${ZPROFILE}"; then
        echo "The Spinnaker GenTL producer path was not found in ${ZPROFILE}. No action performed."
        exit 0
    fi

    check_for_config_file_and_permission_level

    TEMP_ZPROFILE=/tmp/temp_zprofile
    ZPROFILE_OWNER=$(ls -ld $ZPROFILE | awk '{print $3}')

    if [ -f $TEMP_ZPROFILE ]; then
        rm $TEMP_ZPROFILE
    fi

    sudo grep -Fxvf $SPINNAKER_ZPROFILE $ZPROFILE > $TEMP_ZPROFILE

    # Ensure we don't change the owner of zsh profile
    if ! chown $ZPROFILE_OWNER $TEMP_ZPROFILE  || ! mv $TEMP_ZPROFILE $ZPROFILE; then
        sudo rm $TEMP_ZPROFILE
        print_error_msg
    fi

    echo "Successfully removed Spinnaker GenTL producer configuration from ${ZPROFILE}."
    echo "To add configuration back, run the script without any parameters."
    echo "Changes will apply to any new terminal session."
fi