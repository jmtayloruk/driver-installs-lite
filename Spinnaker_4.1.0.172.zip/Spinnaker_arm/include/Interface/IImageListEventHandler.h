//=============================================================================
// Copyright (c) 2001-2024 FLIR Systems, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

#ifndef FLIR_SPINNAKER_IIMAGELIST_EVENT_HANDLER_H
#define FLIR_SPINNAKER_IIMAGELIST_EVENT_HANDLER_H

#include "EventHandler.h"
#include "Spinnaker.h"

namespace Spinnaker
{
    class SPINNAKER_API IImageListEventHandler : public virtual EventHandler
    {
        friend class EventCallbackInfo;

      public:
        virtual ~IImageListEventHandler(){};

      protected:
        IImageListEventHandler()
        {
            SetEventType(SPINNAKER_EVENT_NEW_BUFFER_LIST);
        };
        IImageListEventHandler(const IImageListEventHandler&){};
        IImageListEventHandler& operator=(const IImageListEventHandler&);

        virtual void OnImageListEvent(ImageList imageList) = 0;
    };
} // namespace Spinnaker

#endif /* FLIR_SPINNAKER_IIMAGELIST_EVENT_HANDLER_H */